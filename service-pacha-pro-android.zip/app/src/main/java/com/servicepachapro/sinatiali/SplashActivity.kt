package com.servicepachapro.sinatiali

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.appcompat.app.AppCompatActivity

/**
 * SplashActivity - Écran de démarrage de SERVICE PACHA PRO.
 *
 * Spécifications appliquées :
 * - Affiche le logo Baobab P doré au centre sur fond Bleu Roi (#1E40AF)
 * - Titre : « SERVICE PACHA PRO »
 * - Slogan : « Tout Sinematiali en un clic »
 * - Indicateur de chargement circulaire
 * - Texte : « Chargement du marché... »
 * - Transition automatique après 2000 ms vers l'écran d'accueil (MainActivity).
 */
@SuppressLint("CustomSplashScreen")
class SplashActivity : AppCompatActivity() {

    private val splashDelayMillis: Long = 2000L
    private val handler = Handler(Looper.getMainLooper())
    private var isNavigated = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        // Minuteur de 2 secondes avant ouverture automatique
        handler.postDelayed({
            navigateToHome()
        }, splashDelayMillis)
    }

    private fun navigateToHome() {
        if (!isNavigated && !isFinishing) {
            isNavigated = true
            val intent = Intent(this@SplashActivity, MainActivity::class.java)
            startActivity(intent)
            finish()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
    }
}
