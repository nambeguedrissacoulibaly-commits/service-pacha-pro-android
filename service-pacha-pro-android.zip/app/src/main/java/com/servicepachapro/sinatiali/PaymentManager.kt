package com.servicepachapro.sinatiali

/**
 * Centralized Payment Gateway Manager for SERVICE PACHA PRO
 * Compatible with Aggregators: KAYBIC AFRICA & Noventis Pay
 * Supported Operators: Orange Money CI, MTN Mobile Money, Moov Money, Wave
 * 
 * SECURITY RULES:
 * - API keys and secret tokens must remain strictly on the backend server.
 * - Never store or transmit client Mobile Money PIN codes.
 * - Payments are verified strictly via secure server-to-server webhooks from the aggregator.
 * - Double payments and double validations are prevented via idempotency keys and transaction locks.
 */

enum class PaymentType {
    MOBILE_MONEY,
    CASH_OR_DELIVERY
}

enum class PaymentOperator(val displayName: String, val operatorCode: String, val icon: String) {
    ORANGE_MONEY("Orange Money Côte d'Ivoire", "OM_CI", "🟠"),
    MTN_MOMO("MTN Mobile Money", "MTN_CI", "🟡"),
    MOOV_MONEY("Moov Money", "MOOV_CI", "🔵"),
    WAVE("Wave", "WAVE_CI", "🌊"),
    CASH_ON_DELIVERY("Espèces à la réception", "CASH", "💵"),
    MOBILE_MONEY_ON_DELIVERY("Mobile Money au livreur", "MM_DELIVERY", "📱")
}

enum class PaymentTransactionStatus(val displayLabel: String) {
    PENDING("En attente"),
    CONFIRMED("Paiement confirmé"),
    FAILED("Paiement échoué"),
    CANCELLED("Paiement annulé"),
    REFUNDING("Remboursement en cours"),
    REFUNDED("Remboursé"),
    CASH_ON_DELIVERY("À payer à la livraison")
}

data class PaymentTransaction(
    val transactionId: String,
    val orderId: String,
    val operator: PaymentOperator,
    val amount: Double,
    val currency: String = "XOF",
    val customerPhone: String,
    val status: PaymentTransactionStatus,
    val aggregatorRef: String? = null,
    val idempotencyKey: String,
    val timestamp: Long = System.currentTimeMillis()
)

/**
 * Stub interface for Aggregator Integration (KAYBIC AFRICA / Noventis Pay)
 */
interface AggregatorPaymentService {
    fun initiatePayment(transaction: PaymentTransaction): Boolean
    fun verifyWebhookSignature(payload: String, signature: String): Boolean
    fun queryTransactionStatus(transactionId: String): PaymentTransactionStatus
}
