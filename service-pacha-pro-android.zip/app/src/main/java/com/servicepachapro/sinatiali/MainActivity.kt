package com.servicepachapro.sinatiali

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import org.json.JSONObject
import java.text.NumberFormat
import java.util.Locale

/**
 * MainActivity - SERVICE PACHA PRO
 *
 * Chaîne complète de commerce local à Sinématiali :
 * 1. Écran d'accueil avec Titre (#1E40AF) et Slogan (#FFD700)
 * 2. Barre de recherche temps réel insensible à la casse
 * 3. 6 Catégories tactiles (Téléphones, Vêtements, Chaussures, Beauté, Maison, Alimentation)
 * 4. Produits populaires dans une grille à 2 colonnes avec « Voir le produit » et « + Ajouter au panier »
 * 5. Fiche détaillée produit (zone photo propre, catégorie, prix, description)
 * 6. Système de panier interactif (+ / - / 🗑 / total en FCFA / badge en direct)
 * 7. Bouton « Passer la commande » dans le panier
 * 8. Formulaire de livraison (Nom, Téléphone, Villes de Côte d'Ivoire, Quartier, Contrôles)
 * 9. Bouton « ← Retour au panier » sans perte de produits
 * 10. Écran de confirmation de commande :
 *     - Récapitulatif des produits, quantités, prix et montant total en FCFA
 *     - Nom et prénom, téléphone, ville et quartier du client
 *     - Bouton « Modifier mes informations »
 *     - Bouton « Confirmer la commande »
 *     - Message officiel : « Votre commande est enregistrée sur cet appareil. Le vendeur doit encore la recevoir pour la traiter. »
 * 11. Espace Administrateur local :
 *     - Accès direct depuis l'application via le bouton « ⚙️ Admin »
 *     - Formulaire d'ajout de produit (nom, prix en FCFA, catégorie, description, photo / symbole visuel)
 *     - Modification et suppression des produits ajoutés
 *     - Dialogue de confirmation avant toute suppression
 *     - Affichage immédiat des produits ajoutés dans la boutique pour les clients
 *     - Conservation des 6 produits de démonstration protégés
 *     - Sauvegarde locale sur l'appareil via SharedPreferences (sans mot de passe prétendu)
 */
class MainActivity : AppCompatActivity() {

    // Modèle de données Produit enrichi
    data class ProductItem(
        val id: Int,
        var name: String,
        var category: String,
        var priceText: String,
        var priceValue: Long,
        var description: String,
        var visualSymbol: String,
        val isCustom: Boolean = false
    )

    // Modèle d'article dans le panier
    data class CartItem(
        val product: ProductItem,
        var quantity: Int
    )

    companion object {
        const val COLOR_BLEU_ROI          = 0xFF1E40AF.toInt() // Bleu Roi officiel #1E40AF
        const val COLOR_OR_PACHA          = 0xFFFFD700.toInt() // Or officiel #FFD700
        const val COLOR_BLANC             = 0xFFFFFFFF.toInt() // Blanc officiel #FFFFFF
        const val COLOR_GRIS_FOND         = 0xFFF8FAFC.toInt() // Gris neutre très clair
        const val COLOR_TEXTE_HINT        = 0xFF94A3B8.toInt() // Placeholder
        const val COLOR_TEXTE_SECONDAIRE  = 0xFF64748B.toInt() // Texte secondaire
        const val COLOR_ROUGE_DANGER      = 0xFFDC2626.toInt() // Rouge confirmation suppression
        private const val PREFS_NAME      = "pacha_admin_prefs"
        private const val KEY_CUSTOM_PROD = "custom_products_json"
    }

    // Villes de Côte d'Ivoire (Sinématiali en priorité)
    private val ivorianCities = listOf(
        "Sinématiali",
        "Korhogo",
        "Ferkessédougou",
        "Bouaké",
        "Yamoussoukro",
        "Abidjan"
    )

    // Catégories officielles de la boutique
    private val storeCategories = listOf(
        "Téléphones",
        "Vêtements",
        "Chaussures",
        "Beauté",
        "Maison",
        "Alimentation"
    )

    // Symboles visuels disponibles pour les photos de produits
    private val availableSymbols = listOf(
        "📱" to "Téléphone / High-Tech",
        "🎧" to "Écouteurs / Audio",
        "👞" to "Chaussures homme",
        "👟" to "Chaussures sport / Baskets",
        "👜" to "Sac à main / Maroquinerie",
        "👗" to "Robe / Mode femme",
        "👕" to "Vêtement / Chemise",
        "✨" to "Parfum & Cosmétique",
        "💡" to "Lampe & Éclairage",
        "🍲" to "Alimentation / Repas",
        "🍚" to "Riz & Céréales",
        "🍎" to "Fruits & Légumes",
        "📦" to "Colis & Divers",
        "🏷️" to "Article boutique"
    )

    // 6 produits de démonstration initiaux
    private val demoProducts = listOf(
        ProductItem(
            id = 1,
            name = "Téléphone Android",
            category = "Téléphones",
            priceText = "45 000 FCFA",
            priceValue = 45000L,
            description = "Smartphone Android performant doté d'un écran HD lumineux, d'une batterie longue durée et d'un appareil photo haute définition. Idéal pour WhatsApp, appels et réseaux sociaux à Sinematiali.",
            visualSymbol = "📱",
            isCustom = false
        ),
        ProductItem(
            id = 2,
            name = "Écouteurs",
            category = "Téléphones",
            priceText = "5 000 FCFA",
            priceValue = 5000L,
            description = "Écouteurs stéréo haute fidélité avec basses profondes, microphone antibruit pour appels téléphoniques nets et confort d'écoute optimal tout au long de la journée.",
            visualSymbol = "🎧",
            isCustom = false
        ),
        ProductItem(
            id = 3,
            name = "Chaussures homme",
            category = "Chaussures",
            priceText = "12 000 FCFA",
            priceValue = 12000L,
            description = "Chaussures habillées et résistantes pour homme. Conception soignée alliant élégance et confort pour le travail, les sorties et les grandes cérémonies.",
            visualSymbol = "👞",
            isCustom = false
        ),
        ProductItem(
            id = 4,
            name = "Sac à main",
            category = "Vêtements",
            priceText = "8 000 FCFA",
            priceValue = 8000L,
            description = "Sac à main élégant pour femme avec plusieurs compartiments intérieurs pratiques et une bandoulière ajustable. Parfait pour vos sorties quotidiennes.",
            visualSymbol = "👜",
            isCustom = false
        ),
        ProductItem(
            id = 5,
            name = "Parfum",
            category = "Beauté",
            priceText = "6 000 FCFA",
            priceValue = 6000L,
            description = "Eau de parfum raffinée aux essences fraîches et boisées. Excellente tenue parfumée du matin jusqu'au soir pour une fraîcheur irréprochable.",
            visualSymbol = "✨",
            isCustom = false
        ),
        ProductItem(
            id = 6,
            name = "Lampe LED",
            category = "Maison",
            priceText = "3 500 FCFA",
            priceValue = 3500L,
            description = "Lampe LED puissante et rechargeable à économie d'énergie. Plusieurs modes d'éclairage réglables pour la maison, le bureau et les devoirs du soir.",
            visualSymbol = "💡",
            isCustom = false
        )
    )

    // Catalogue actif en mémoire (6 démos + produits ajoutés par l'administrateur)
    private val allProducts = mutableListOf<ProductItem>()

    // Panier d'achat en mémoire (idProduit -> CartItem)
    private val cartMap = LinkedHashMap<Int, CartItem>()

    // Gestionnaire de persistance locale durable
    private val localStorageManager by lazy { LocalStorageManager(this) }

    // Mémoire des informations de livraison du client
    private var savedClientName: String = ""
    private var savedClientPhone: String = ""
    private var savedClientCityIndex: Int = 0
    private var savedClientDistrict: String = ""

    // Vues dynamiques principales
    private lateinit var productsContainer: LinearLayout
    private lateinit var tvCartBadge: TextView
    private lateinit var etSearch: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Chargement initial des produits depuis la mémoire locale
        loadProductsFromStorage()

        // 1. ScrollView racine
        val scrollView = ScrollView(this).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            setBackgroundColor(COLOR_BLANC)
            isVerticalScrollBarEnabled = false
        }

        // 2. Conteneur vertical principal
        val mainContainer = LinearLayout(this).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            orientation = LinearLayout.VERTICAL
            val padH = dpToPx(18)
            val padTop = dpToPx(24)
            val padBottom = dpToPx(40)
            setPadding(padH, padTop, padH, padBottom)
        }
        scrollView.addView(mainContainer)

        // 3. Barre d'en-tête supérieure avec Titre, Bouton Admin et Bouton Panier
        val topBarLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = dpToPx(4)
            }
            layoutParams = params
        }

        // Titre SERVICE PACHA PRO en bleu roi
        val tvTitle = TextView(this).apply {
            text = "SERVICE PACHA PRO"
            setTextColor(COLOR_BLEU_ROI)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 19f)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            letterSpacing = 0.02f
            val params = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            layoutParams = params
        }
        topBarLayout.addView(tvTitle)

        // Actions à droite : Bouton Admin + Bouton Panier
        val headerActionsLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        // Bouton « ⚙️ Admin »
        val btnAdmin = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            val bg = GradientDrawable().apply {
                setColor(COLOR_BLANC)
                setStroke(dpToPx(1.5f), COLOR_OR_PACHA)
                cornerRadius = dpToPx(16).toFloat()
            }
            background = bg
            val padH = dpToPx(10)
            val padV = dpToPx(6)
            setPadding(padH, padV, padH, padV)
            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                rightMargin = dpToPx(8)
            }
            layoutParams = params
            isClickable = true
            isFocusable = true
            setOnClickListener {
                openAdminDialog()
            }
        }

        val tvAdminText = TextView(this).apply {
            text = "⚙️ Admin"
            setTextColor(COLOR_BLEU_ROI)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        btnAdmin.addView(tvAdminText)
        headerActionsLayout.addView(btnAdmin)

        // Bouton Panier interactif avec compteur
        val cartButtonContainer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            val bg = GradientDrawable().apply {
                setColor(COLOR_BLEU_ROI)
                cornerRadius = dpToPx(16).toFloat()
            }
            background = bg
            val padH = dpToPx(11)
            val padV = dpToPx(6)
            setPadding(padH, padV, padH, padV)
            isClickable = true
            isFocusable = true
            setOnClickListener {
                openCartDialog()
            }
        }

        val tvCartIcon = TextView(this).apply {
            text = "🛒 "
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
        }
        cartButtonContainer.addView(tvCartIcon)

        tvCartBadge = TextView(this).apply {
            text = "Panier (0)"
            setTextColor(COLOR_BLANC)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        cartButtonContainer.addView(tvCartBadge)
        headerActionsLayout.addView(cartButtonContainer)

        topBarLayout.addView(headerActionsLayout)
        mainContainer.addView(topBarLayout)

        // 4. Slogan « Tout Sinematiali en un clic » en doré (#FFD700)
        val tvSlogan = TextView(this).apply {
            text = "Tout Sinematiali en un clic"
            setTextColor(COLOR_OR_PACHA)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = dpToPx(18)
            }
            layoutParams = params
        }
        mainContainer.addView(tvSlogan)

        // 5. Barre de recherche fonctionnelle
        val searchBackground = GradientDrawable().apply {
            setColor(COLOR_GRIS_FOND)
            setStroke(dpToPx(1.5f), COLOR_BLEU_ROI)
            cornerRadius = dpToPx(12).toFloat()
        }

        etSearch = EditText(this).apply {
            hint = "Rechercher un produit..."
            setHintTextColor(COLOR_TEXTE_HINT)
            setTextColor(COLOR_BLEU_ROI)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            background = searchBackground
            inputType = InputType.TYPE_CLASS_TEXT
            maxLines = 1
            val padH = dpToPx(16)
            val padV = dpToPx(11)
            setPadding(padH, padV, padH, padV)
            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = dpToPx(24)
            }
            layoutParams = params
        }
        mainContainer.addView(etSearch)

        // 6. Section « Nos catégories »
        mainContainer.addView(createSectionHeader("Nos catégories"))

        val categories = storeCategories
        val spacingCatPx = dpToPx(12)

        for (i in categories.indices step 2) {
            val rowLayout = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                weightSum = 2f
                val params = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply {
                    bottomMargin = spacingCatPx
                }
                layoutParams = params
            }

            val cardLeft = createCategoryCard(categories[i])
            val leftParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                rightMargin = spacingCatPx / 2
            }
            rowLayout.addView(cardLeft, leftParams)

            if (i + 1 < categories.size) {
                val cardRight = createCategoryCard(categories[i + 1])
                val rightParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                    leftMargin = spacingCatPx / 2
                }
                rowLayout.addView(cardRight, rightParams)
            } else {
                val spacer = View(this).apply {
                    val params = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f).apply {
                        leftMargin = spacingCatPx / 2
                    }
                    layoutParams = params
                }
                rowLayout.addView(spacer)
            }

            mainContainer.addView(rowLayout)
        }

        // Espace intercalaire
        val sectionSpacer = View(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dpToPx(16)
            )
        }
        mainContainer.addView(sectionSpacer)

        // 7. Section « Produits populaires »
        mainContainer.addView(createSectionHeader("Produits populaires"))

        // Conteneur dynamique des produits
        productsContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }
        mainContainer.addView(productsContainer)

        // Affichage initial des produits
        refreshCatalogDisplay()

        // 8. Écouteur de recherche en temps réel
        etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                refreshCatalogDisplay()
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        setContentView(scrollView)
    }

    /**
     * Charge les produits depuis la mémoire locale (LocalStorageManager).
     * Conserve toujours les 6 produits de démonstration protégés et évite les doublons.
     */
    private fun loadProductsFromStorage() {
        allProducts.clear()
        allProducts.addAll(demoProducts)
        val customItems = localStorageManager.loadCustomProducts()
        allProducts.addAll(customItems)
    }

    /**
     * Enregistre les produits personnalisés ajoutés dans le stockage local durable.
     */
    private fun saveCustomProductsToStorage() {
        localStorageManager.saveCustomProducts(allProducts)
    }

    /**
     * Enregistre une commande confirmée dans le stockage local durable avec
     * les coordonnées du client, les articles détaillés et le montant total en FCFA.
     */
    private fun saveConfirmedOrder(
        clientName: String,
        clientPhone: String,
        clientCity: String,
        clientDistrict: String
    ): OrderRecord {
        val itemsList = cartMap.values.map { cartItem ->
            OrderItemRecord(
                productId = cartItem.product.id,
                productName = cartItem.product.name,
                unitPrice = cartItem.product.priceValue,
                quantity = cartItem.quantity,
                subtotal = cartItem.product.priceValue * cartItem.quantity
            )
        }
        val totalAmount = cartMap.values.sumOf { it.product.priceValue * it.quantity }
        val order = OrderRecord(
            id = localStorageManager.generateOrderId(),
            timestamp = System.currentTimeMillis(),
            dateFormatted = localStorageManager.formatCurrentDate(),
            clientName = clientName,
            clientPhone = clientPhone,
            clientCity = clientCity,
            clientDistrict = clientDistrict,
            totalAmount = totalAmount,
            items = itemsList
        )
        localStorageManager.saveOrder(order)
        return order
    }

    /**
     * Rafraîchit l'affichage du catalogue selon la recherche actuelle.
     */
    private fun refreshCatalogDisplay() {
        val query = if (::etSearch.isInitialized) etSearch.text?.toString()?.trim() ?: "" else ""
        if (query.isEmpty()) {
            renderProducts(allProducts)
        } else {
            val filtered = allProducts.filter { p ->
                p.name.contains(query, ignoreCase = true)
            }
            renderProducts(filtered)
        }
    }

    // =========================================================================
    // SECTION ADMINISTRATION (GESTION LOCALE DU CATALOGUE)
    // =========================================================================

    /**
     * Ouvre l'Espace Administrateur pour gérer les produits de la boutique.
     */
    private fun openAdminDialog() {
        val adminDialog = Dialog(this)
        adminDialog.requestWindowFeature(Window.FEATURE_NO_TITLE)

        val rootScroll = ScrollView(this).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            setBackgroundColor(COLOR_BLANC)
            isVerticalScrollBarEnabled = false
        }

        val adminRoot = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val pad = dpToPx(18)
            setPadding(pad, pad, pad, pad)
        }
        rootScroll.addView(adminRoot)

        // 1. Barre d'en-tête
        val headerLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = dpToPx(12)
            }
            layoutParams = params
        }

        val tvHeader = TextView(this).apply {
            text = "Espace Administrateur"
            setTextColor(COLOR_BLEU_ROI)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            val params = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            layoutParams = params
        }
        headerLayout.addView(tvHeader)

        val btnClose = TextView(this).apply {
            text = "✕"
            setTextColor(COLOR_TEXTE_SECONDAIRE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
            val padH = dpToPx(8)
            setPadding(padH, 0, padH, 0)
            isClickable = true
            isFocusable = true
            setOnClickListener { adminDialog.dismiss() }
        }
        headerLayout.addView(btnClose)
        adminRoot.addView(headerLayout)

        // 2. Encadré d'information sur la persistance locale et la sécurité
        val infoBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val bg = GradientDrawable().apply {
                setColor(Color.parseColor("#EFF6FF"))
                setStroke(dpToPx(1f), COLOR_BLEU_ROI)
                cornerRadius = dpToPx(10).toFloat()
            }
            background = bg
            val padBox = dpToPx(12)
            setPadding(padBox, padBox, padBox, padBox)
            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = dpToPx(14)
            }
            layoutParams = params
        }

        val tvInfoTitle = TextView(this).apply {
            text = "ℹ️ Sauvegarde locale sur l'appareil (sans mot de passe)"
            setTextColor(COLOR_BLEU_ROI)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = dpToPx(4)
            }
            layoutParams = params
        }
        infoBox.addView(tvInfoTitle)

        val tvInfoBody = TextView(this).apply {
            text = "Les produits ajoutés et les commandes confirmées sont conservés de façon durable dans la mémoire locale de ce téléphone (LocalStorageManager). Les données persistent après fermeture et réouverture. Cette sauvegarde reste locale à cet appareil et n'est pas synchronisée avec d'autres téléphones."
            setTextColor(COLOR_TEXTE_SECONDAIRE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            setLineSpacing(dpToPx(2).toFloat(), 1f)
        }
        infoBox.addView(tvInfoBody)
        adminRoot.addView(infoBox)

        // 3. Barre d'onglets : [Produits] / [Commandes enregistrées]
        val tabsRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            weightSum = 2f
            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = dpToPx(14)
            }
            layoutParams = params
        }

        val btnTabProducts = Button(this).apply {
            val customCount = allProducts.count { it.isCustom }
            text = "🛍️ Produits ($customCount)"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAllCaps = false
            val padV = dpToPx(8)
            setPadding(0, padV, 0, padV)
        }
        val tabProdParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
            rightMargin = dpToPx(4)
        }
        tabsRow.addView(btnTabProducts, tabProdParams)

        val btnTabOrders = Button(this).apply {
            val ordersCount = localStorageManager.loadOrders().size
            text = "📦 Commandes ($ordersCount)"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAllCaps = false
            val padV = dpToPx(8)
            setPadding(0, padV, 0, padV)
        }
        val tabOrdersParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
            leftMargin = dpToPx(4)
        }
        tabsRow.addView(btnTabOrders, tabOrdersParams)
        adminRoot.addView(tabsRow)

        // Conteneurs des onglets
        val productsTabContent = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }
        adminRoot.addView(productsTabContent)

        val ordersTabContent = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }
        adminRoot.addView(ordersTabContent)

        // Style des boutons d'onglets
        fun updateTabStyles(selectedTab: Int) {
            val activeBg = GradientDrawable().apply {
                setColor(COLOR_BLEU_ROI)
                cornerRadius = dpToPx(8).toFloat()
            }
            val inactiveBg = GradientDrawable().apply {
                setColor(COLOR_GRIS_FOND)
                cornerRadius = dpToPx(8).toFloat()
                setStroke(dpToPx(1f), Color.parseColor("#CBD5E1"))
            }

            if (selectedTab == 0) {
                btnTabProducts.background = activeBg
                btnTabProducts.setTextColor(COLOR_BLANC)
                btnTabOrders.background = inactiveBg
                btnTabOrders.setTextColor(COLOR_TEXTE_SECONDAIRE)
                productsTabContent.visibility = View.VISIBLE
                ordersTabContent.visibility = View.GONE
            } else {
                btnTabProducts.background = inactiveBg
                btnTabProducts.setTextColor(COLOR_TEXTE_SECONDAIRE)
                btnTabOrders.background = activeBg
                btnTabOrders.setTextColor(COLOR_BLANC)
                productsTabContent.visibility = View.GONE
                ordersTabContent.visibility = View.VISIBLE
            }
        }

        btnTabProducts.setOnClickListener { updateTabStyles(0) }
        btnTabOrders.setOnClickListener { updateTabStyles(1) }
        updateTabStyles(0)

        // ---------------------------------------------------------------------
        // CONTENU ONGLET 1 : PRODUITS
        // ---------------------------------------------------------------------

        val btnAddProduct = Button(this).apply {
            text = "+ Ajouter un produit"
            setTextColor(COLOR_BLANC)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            val bg = GradientDrawable().apply {
                setColor(COLOR_BLEU_ROI)
                cornerRadius = dpToPx(10).toFloat()
            }
            background = bg
            isAllCaps = false
            val padV = dpToPx(11)
            setPadding(dpToPx(16), padV, dpToPx(16), padV)
            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = dpToPx(16)
            }
            layoutParams = params

            setOnClickListener {
                openAddEditProductDialog(null, adminDialog)
            }
        }
        productsTabContent.addView(btnAddProduct)

        val customListContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }
        productsTabContent.addView(customListContainer)

        fun populateAdminProductLists() {
            customListContainer.removeAllViews()
            val customProducts = allProducts.filter { it.isCustom }
            btnTabProducts.text = "🛍️ Produits (${customProducts.size})"

            val sectionCustomHeader = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                val params = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply {
                    bottomMargin = dpToPx(10)
                }
                layoutParams = params
            }

            val dotCustom = View(this).apply {
                val bg = GradientDrawable().apply {
                    setColor(COLOR_OR_PACHA)
                    shape = GradientDrawable.OVAL
                }
                background = bg
                val size = dpToPx(8)
                val params = LinearLayout.LayoutParams(size, size).apply {
                    rightMargin = dpToPx(8)
                }
                layoutParams = params
            }
            sectionCustomHeader.addView(dotCustom)

            val tvCustomTitle = TextView(this).apply {
                text = "Produits ajoutés par vous (${customProducts.size})"
                setTextColor(COLOR_BLEU_ROI)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            }
            sectionCustomHeader.addView(tvCustomTitle)
            customListContainer.addView(sectionCustomHeader)

            if (customProducts.isEmpty()) {
                val emptyCustomCard = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.CENTER
                    val bg = GradientDrawable().apply {
                        setColor(COLOR_GRIS_FOND)
                        cornerRadius = dpToPx(8).toFloat()
                    }
                    background = bg
                    val padEmpty = dpToPx(16)
                    setPadding(padEmpty, padEmpty, padEmpty, padEmpty)
                    val params = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    ).apply {
                        bottomMargin = dpToPx(18)
                    }
                    layoutParams = params
                }

                val tvEmpty = TextView(this).apply {
                    text = "Aucun produit personnalisé ajouté pour le moment.\nUtilisez le bouton ci-dessus pour enrichir le catalogue."
                    setTextColor(COLOR_TEXTE_SECONDAIRE)
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                    gravity = Gravity.CENTER
                }
                emptyCustomCard.addView(tvEmpty)
                customListContainer.addView(emptyCustomCard)
            } else {
                for (item in customProducts) {
                    val card = createAdminProductItemView(item, onEdit = {
                        openAddEditProductDialog(item, adminDialog)
                    }, onDelete = {
                        openDeleteConfirmationDialog(item) {
                            populateAdminProductLists()
                        }
                    })
                    customListContainer.addView(card)
                }
            }

            // Section : Produits de démonstration initiaux (protégés)
            val sectionDemoHeader = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                val params = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply {
                    topMargin = dpToPx(12)
                    bottomMargin = dpToPx(10)
                }
                layoutParams = params
            }

            val dotDemo = View(this).apply {
                val bg = GradientDrawable().apply {
                    setColor(COLOR_TEXTE_SECONDAIRE)
                    shape = GradientDrawable.OVAL
                }
                background = bg
                val size = dpToPx(8)
                val params = LinearLayout.LayoutParams(size, size).apply {
                    rightMargin = dpToPx(8)
                }
                layoutParams = params
            }
            sectionDemoHeader.addView(dotDemo)

            val tvDemoTitle = TextView(this).apply {
                text = "Produits de démonstration (6) — Protégés"
                setTextColor(COLOR_TEXTE_SECONDAIRE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            }
            sectionDemoHeader.addView(tvDemoTitle)
            customListContainer.addView(sectionDemoHeader)

            for (demo in demoProducts) {
                val demoCard = createDemoProductItemView(demo)
                customListContainer.addView(demoCard)
            }
        }

        populateAdminProductLists()

        // ---------------------------------------------------------------------
        // CONTENU ONGLET 2 : COMMANDES ENREGISTRÉES
        // ---------------------------------------------------------------------

        fun populateAdminOrdersList() {
            ordersTabContent.removeAllViews()
            val orders = localStorageManager.loadOrders()
            btnTabOrders.text = "📦 Commandes (${orders.size})"

            if (orders.isEmpty()) {
                val emptyOrdersCard = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.CENTER
                    val bg = GradientDrawable().apply {
                        setColor(COLOR_GRIS_FOND)
                        cornerRadius = dpToPx(10).toFloat()
                        setStroke(dpToPx(1f), Color.parseColor("#E2E8F0"))
                    }
                    background = bg
                    val padEmpty = dpToPx(24)
                    setPadding(padEmpty, padEmpty, padEmpty, padEmpty)
                    val params = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    ).apply {
                        bottomMargin = dpToPx(14)
                    }
                    layoutParams = params
                }

                val tvEmptyIcon = TextView(this).apply {
                    text = "📦"
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 32f)
                    gravity = Gravity.CENTER
                    val params = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    ).apply {
                        bottomMargin = dpToPx(8)
                    }
                    layoutParams = params
                }
                emptyOrdersCard.addView(tvEmptyIcon)

                val tvEmptyTitle = TextView(this).apply {
                    text = "Aucune commande enregistrée"
                    setTextColor(COLOR_BLEU_ROI)
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
                    typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                    gravity = Gravity.CENTER
                    val params = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    ).apply {
                        bottomMargin = dpToPx(4)
                    }
                    layoutParams = params
                }
                emptyOrdersCard.addView(tvEmptyTitle)

                val tvEmptyDesc = TextView(this).apply {
                    text = "Les commandes confirmées par vos clients apparaîtront ici avec toutes leurs coordonnées et articles commandés."
                    setTextColor(COLOR_TEXTE_SECONDAIRE)
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                    gravity = Gravity.CENTER
                }
                emptyOrdersCard.addView(tvEmptyDesc)

                ordersTabContent.addView(emptyOrdersCard)
            } else {
                // Barre récapitulative et bouton Tout effacer
                val ordersTopRow = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    val params = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    ).apply {
                        bottomMargin = dpToPx(12)
                    }
                    layoutParams = params
                }

                val tvOrdersCount = TextView(this).apply {
                    text = "${orders.size} commande(s) enregistrée(s)"
                    setTextColor(COLOR_BLEU_ROI)
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
                    typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                    val params = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                    layoutParams = params
                }
                ordersTopRow.addView(tvOrdersCount)

                val btnClearAll = TextView(this).apply {
                    text = "Tout effacer"
                    setTextColor(COLOR_ROUGE_DANGER)
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
                    typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                    isClickable = true
                    isFocusable = true
                    val pad = dpToPx(6)
                    setPadding(pad, pad, pad, pad)
                    setOnClickListener {
                        openClearAllOrdersConfirmationDialog {
                            populateAdminOrdersList()
                        }
                    }
                }
                ordersTopRow.addView(btnClearAll)
                ordersTabContent.addView(ordersTopRow)

                // Liste des commandes
                for (order in orders) {
                    val orderCard = createAdminOrderItemView(order) {
                        openDeleteOrderConfirmationDialog(order) {
                            populateAdminOrdersList()
                        }
                    }
                    ordersTabContent.addView(orderCard)
                }
            }
        }

        populateAdminOrdersList()

        // 5. Bouton Fermer en bas
        val btnCloseBottom = Button(this).apply {
            text = "Retour à la boutique"
            setTextColor(COLOR_BLEU_ROI)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            val bg = GradientDrawable().apply {
                setColor(COLOR_GRIS_FOND)
                setStroke(dpToPx(1.2f), COLOR_BLEU_ROI)
                cornerRadius = dpToPx(10).toFloat()
            }
            background = bg
            isAllCaps = false
            val padV = dpToPx(10)
            setPadding(dpToPx(16), padV, dpToPx(16), padV)
            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                topMargin = dpToPx(16)
                bottomMargin = dpToPx(8)
            }
            layoutParams = params
            setOnClickListener { adminDialog.dismiss() }
        }
        adminRoot.addView(btnCloseBottom)

        adminDialog.setContentView(rootScroll)
        adminDialog.window?.apply {
            setLayout(
                (resources.displayMetrics.widthPixels * 0.94).toInt(),
                (resources.displayMetrics.heightPixels * 0.88).toInt()
            )
            setBackgroundDrawableResource(android.R.color.transparent)
        }

        adminDialog.show()
    }

    /**
     * Crée une carte visuelle détaillée pour une commande enregistrée dans l'Espace Administrateur.
     */
    private fun createAdminOrderItemView(
        order: OrderRecord,
        onDelete: () -> Unit
    ): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val bg = GradientDrawable().apply {
                setColor(COLOR_BLANC)
                setStroke(dpToPx(1f), Color.parseColor("#CBD5E1"))
                cornerRadius = dpToPx(12).toFloat()
            }
            background = bg
            val pad = dpToPx(12)
            setPadding(pad, pad, pad, pad)
            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = dpToPx(10)
            }
            layoutParams = params
        }

        // Ligne d'en-tête de commande : ID + Date
        val headerRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = dpToPx(8)
            }
            layoutParams = params
        }

        val tvOrderId = TextView(this).apply {
            text = order.id
            setTextColor(COLOR_BLEU_ROI)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            val params = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            layoutParams = params
        }
        headerRow.addView(tvOrderId)

        val tvDate = TextView(this).apply {
            text = order.dateFormatted
            setTextColor(COLOR_TEXTE_SECONDAIRE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f)
        }
        headerRow.addView(tvDate)
        card.addView(headerRow)

        // Encadré client (Nom, Téléphone, Ville, Quartier)
        val clientBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val bg = GradientDrawable().apply {
                setColor(Color.parseColor("#EFF6FF"))
                cornerRadius = dpToPx(8).toFloat()
            }
            background = bg
            val padBox = dpToPx(8)
            setPadding(padBox, padBox, padBox, padBox)
            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = dpToPx(8)
            }
            layoutParams = params
        }

        val tvClient = TextView(this).apply {
            text = "👤 ${order.clientName} • 📞 ${order.clientPhone}"
            setTextColor(Color.parseColor("#1E293B"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = dpToPx(2)
            }
            layoutParams = params
        }
        clientBox.addView(tvClient)

        val tvLocation = TextView(this).apply {
            text = "📍 ${order.clientCity} (Côte d'Ivoire) • 🏡 ${order.clientDistrict}"
            setTextColor(Color.parseColor("#475569"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
        }
        clientBox.addView(tvLocation)
        card.addView(clientBox)

        // Articles commandés
        val itemsBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = dpToPx(8)
            }
            layoutParams = params
        }

        for (item in order.items) {
            val itemRow = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                val params = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply {
                    bottomMargin = dpToPx(3)
                }
                layoutParams = params
            }

            val tvItemTitle = TextView(this).apply {
                text = "• ${item.quantity}x ${item.productName}"
                setTextColor(Color.parseColor("#334155"))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
                val params = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                layoutParams = params
            }
            itemRow.addView(tvItemTitle)

            val tvItemPrice = TextView(this).apply {
                text = "${NumberFormat.getNumberInstance(Locale.FRANCE).format(item.subtotal)} FCFA"
                setTextColor(Color.parseColor("#64748B"))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            }
            itemRow.addView(tvItemPrice)
            itemsBox.addView(itemRow)
        }
        card.addView(itemsBox)

        // Ligne de séparation
        val divider = View(this).apply {
            setBackgroundColor(Color.parseColor("#E2E8F0"))
            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dpToPx(1)
            ).apply {
                bottomMargin = dpToPx(8)
            }
            layoutParams = params
        }
        card.addView(divider)

        // Pied de carte : Montant Total + Bouton Supprimer
        val footerRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        val tvTotal = TextView(this).apply {
            text = "Total : ${NumberFormat.getNumberInstance(Locale.FRANCE).format(order.totalAmount)} FCFA"
            setTextColor(Color.parseColor("#B45309"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            val params = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            layoutParams = params
        }
        footerRow.addView(tvTotal)

        val btnDelete = TextView(this).apply {
            text = "🗑️ Supprimer"
            setTextColor(COLOR_ROUGE_DANGER)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            val bg = GradientDrawable().apply {
                setColor(Color.parseColor("#FEF2F2"))
                setStroke(dpToPx(1f), Color.parseColor("#FECACA"))
                cornerRadius = dpToPx(6).toFloat()
            }
            background = bg
            val padH = dpToPx(8)
            val padV = dpToPx(4)
            setPadding(padH, padV, padH, padV)
            isClickable = true
            isFocusable = true
            setOnClickListener { onDelete() }
        }
        footerRow.addView(btnDelete)
        card.addView(footerRow)

        return card
    }

    /**
     * Confirmation de suppression d'une commande enregistrée.
     */
    private fun openDeleteOrderConfirmationDialog(
        order: OrderRecord,
        onDeleted: () -> Unit
    ) {
        val confirmDialog = Dialog(this)
        confirmDialog.requestWindowFeature(Window.FEATURE_NO_TITLE)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(COLOR_BLANC)
            val pad = dpToPx(20)
            setPadding(pad, pad, pad, pad)
            val bg = GradientDrawable().apply {
                setColor(COLOR_BLANC)
                cornerRadius = dpToPx(14).toFloat()
            }
            background = bg
        }

        val tvTitle = TextView(this).apply {
            text = "Supprimer la commande ?"
            setTextColor(COLOR_BLEU_ROI)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = dpToPx(10)
            }
            layoutParams = params
        }
        root.addView(tvTitle)

        val tvMsg = TextView(this).apply {
            text = "Voulez-vous supprimer définitivement la commande ${order.id} du client ${order.clientName} (${NumberFormat.getNumberInstance(Locale.FRANCE).format(order.totalAmount)} FCFA) ? Cette action est irréversible."
            setTextColor(Color.parseColor("#475569"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            setLineSpacing(dpToPx(2).toFloat(), 1f)
            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = dpToPx(16)
            }
            layoutParams = params
        }
        root.addView(tvMsg)

        val btnRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            weightSum = 2f
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        val btnCancel = Button(this).apply {
            text = "Annuler"
            setTextColor(COLOR_TEXTE_SECONDAIRE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            val bg = GradientDrawable().apply {
                setColor(COLOR_GRIS_FOND)
                cornerRadius = dpToPx(8).toFloat()
            }
            background = bg
            isAllCaps = false
            setOnClickListener { confirmDialog.dismiss() }
        }
        val cancelParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
            rightMargin = dpToPx(6)
        }
        btnRow.addView(btnCancel, cancelParams)

        val btnDelete = Button(this).apply {
            text = "Supprimer"
            setTextColor(COLOR_BLANC)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            val bg = GradientDrawable().apply {
                setColor(COLOR_ROUGE_DANGER)
                cornerRadius = dpToPx(8).toFloat()
            }
            background = bg
            isAllCaps = false
            setOnClickListener {
                localStorageManager.deleteOrder(order.id)
                confirmDialog.dismiss()
                onDeleted()
                Toast.makeText(this@MainActivity, "Commande supprimée.", Toast.LENGTH_SHORT).show()
            }
        }
        val delParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
            leftMargin = dpToPx(6)
        }
        btnRow.addView(btnDelete, delParams)
        root.addView(btnRow)

        confirmDialog.setContentView(root)
        confirmDialog.window?.apply {
            setLayout(
                (resources.displayMetrics.widthPixels * 0.88).toInt(),
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            setBackgroundDrawableResource(android.R.color.transparent)
        }
        confirmDialog.show()
    }

    /**
     * Confirmation de suppression de toutes les commandes enregistrées.
     */
    private fun openClearAllOrdersConfirmationDialog(onCleared: () -> Unit) {
        val confirmDialog = Dialog(this)
        confirmDialog.requestWindowFeature(Window.FEATURE_NO_TITLE)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(COLOR_BLANC)
            val pad = dpToPx(20)
            setPadding(pad, pad, pad, pad)
            val bg = GradientDrawable().apply {
                setColor(COLOR_BLANC)
                cornerRadius = dpToPx(14).toFloat()
            }
            background = bg
        }

        val tvTitle = TextView(this).apply {
            text = "Effacer toutes les commandes ?"
            setTextColor(COLOR_ROUGE_DANGER)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = dpToPx(10)
            }
            layoutParams = params
        }
        root.addView(tvTitle)

        val tvMsg = TextView(this).apply {
            text = "Êtes-vous sûr de vouloir supprimer la totalité de l'historique des commandes locales de ce téléphone ? Cette action ne peut pas être annulée."
            setTextColor(Color.parseColor("#475569"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            setLineSpacing(dpToPx(2).toFloat(), 1f)
            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = dpToPx(16)
            }
            layoutParams = params
        }
        root.addView(tvMsg)

        val btnRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            weightSum = 2f
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        val btnCancel = Button(this).apply {
            text = "Annuler"
            setTextColor(COLOR_TEXTE_SECONDAIRE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            val bg = GradientDrawable().apply {
                setColor(COLOR_GRIS_FOND)
                cornerRadius = dpToPx(8).toFloat()
            }
            background = bg
            isAllCaps = false
            setOnClickListener { confirmDialog.dismiss() }
        }
        val cancelParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
            rightMargin = dpToPx(6)
        }
        btnRow.addView(btnCancel, cancelParams)

        val btnClear = Button(this).apply {
            text = "Tout effacer"
            setTextColor(COLOR_BLANC)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            val bg = GradientDrawable().apply {
                setColor(COLOR_ROUGE_DANGER)
                cornerRadius = dpToPx(8).toFloat()
            }
            background = bg
            isAllCaps = false
            setOnClickListener {
                localStorageManager.clearAllOrders()
                confirmDialog.dismiss()
                onCleared()
                Toast.makeText(this@MainActivity, "Toutes les commandes ont été effacées.", Toast.LENGTH_SHORT).show()
            }
        }
        val clearParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
            leftMargin = dpToPx(6)
        }
        btnRow.addView(btnClear, clearParams)
        root.addView(btnRow)

        confirmDialog.setContentView(root)
        confirmDialog.window?.apply {
            setLayout(
                (resources.displayMetrics.widthPixels * 0.88).toInt(),
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            setBackgroundDrawableResource(android.R.color.transparent)
        }
        confirmDialog.show()
    }

    /**
     * Crée une carte de produit gérable dans l'Espace Administrateur.
     */
    private fun createAdminProductItemView(
        product: ProductItem,
        onEdit: () -> Unit,
        onDelete: () -> Unit
    ): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            val bg = GradientDrawable().apply {
                setColor(COLOR_BLANC)
                setStroke(dpToPx(1f), Color.parseColor("#CBD5E1"))
                cornerRadius = dpToPx(10).toFloat()
            }
            background = bg
            val pad = dpToPx(10)
            setPadding(pad, pad, pad, pad)
            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = dpToPx(8)
            }
            layoutParams = params
        }

        // Emplacement photo / symbole visuel
        val photoBox = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            val bg = GradientDrawable().apply {
                setColor(COLOR_GRIS_FOND)
                cornerRadius = dpToPx(8).toFloat()
                setStroke(dpToPx(1f), Color.parseColor("#E2E8F0"))
            }
            background = bg
            val size = dpToPx(44)
            layoutParams = LinearLayout.LayoutParams(size, size).apply {
                rightMargin = dpToPx(10)
            }
        }
        val tvSymbol = TextView(this).apply {
            text = product.visualSymbol
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
            gravity = Gravity.CENTER
        }
        photoBox.addView(tvSymbol)
        card.addView(photoBox)

        // Infos textuelles
        val infoCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val params = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                rightMargin = dpToPx(8)
            }
            layoutParams = params
        }

        val tvName = TextView(this).apply {
            text = product.name
            setTextColor(COLOR_BLEU_ROI)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            maxLines = 1
        }
        infoCol.addView(tvName)

        val metaRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                topMargin = dpToPx(2)
            }
            layoutParams = params
        }

        val tvPrice = TextView(this).apply {
            text = product.priceText
            setTextColor(Color.parseColor("#B45309"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                rightMargin = dpToPx(6)
            }
            layoutParams = params
        }
        metaRow.addView(tvPrice)

        val tvCat = TextView(this).apply {
            text = "• ${product.category}"
            setTextColor(COLOR_TEXTE_SECONDAIRE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
        }
        metaRow.addView(tvCat)
        infoCol.addView(metaRow)
        card.addView(infoCol)

        // Boutons d'action Éditer / Supprimer
        val actionsCol = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val btnEdit = Button(this).apply {
            text = "✏️"
            setTextColor(COLOR_BLEU_ROI)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            val bg = GradientDrawable().apply {
                setColor(COLOR_GRIS_FOND)
                cornerRadius = dpToPx(6).toFloat()
                setStroke(dpToPx(1f), COLOR_BLEU_ROI)
            }
            background = bg
            isAllCaps = false
            val size = dpToPx(34)
            val params = LinearLayout.LayoutParams(size, size).apply {
                rightMargin = dpToPx(6)
            }
            layoutParams = params
            setOnClickListener { onEdit() }
        }
        actionsCol.addView(btnEdit)

        val btnDelete = Button(this).apply {
            text = "🗑️"
            setTextColor(COLOR_ROUGE_DANGER)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            val bg = GradientDrawable().apply {
                setColor(Color.parseColor("#FEF2F2"))
                cornerRadius = dpToPx(6).toFloat()
                setStroke(dpToPx(1f), Color.parseColor("#FCA5A5"))
            }
            background = bg
            isAllCaps = false
            val size = dpToPx(34)
            layoutParams = LinearLayout.LayoutParams(size, size)
            setOnClickListener { onDelete() }
        }
        actionsCol.addView(btnDelete)

        card.addView(actionsCol)
        return card
    }

    /**
     * Crée une carte de produit de démonstration protégé.
     */
    private fun createDemoProductItemView(product: ProductItem): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            val bg = GradientDrawable().apply {
                setColor(Color.parseColor("#F8FAFC"))
                setStroke(dpToPx(1f), Color.parseColor("#E2E8F0"))
                cornerRadius = dpToPx(8).toFloat()
            }
            background = bg
            val pad = dpToPx(8)
            setPadding(pad, pad, pad, pad)
            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = dpToPx(6)
            }
            layoutParams = params
        }

        val tvIcon = TextView(this).apply {
            text = product.visualSymbol
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                rightMargin = dpToPx(8)
                leftMargin = dpToPx(4)
            }
            layoutParams = params
        }
        card.addView(tvIcon)

        val infoCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val params = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            layoutParams = params
        }

        val tvName = TextView(this).apply {
            text = product.name
            setTextColor(COLOR_BLEU_ROI)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        infoCol.addView(tvName)

        val tvPrice = TextView(this).apply {
            text = "${product.priceText} • ${product.category}"
            setTextColor(COLOR_TEXTE_SECONDAIRE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
        }
        infoCol.addView(tvPrice)
        card.addView(infoCol)

        val badgeDemo = TextView(this).apply {
            text = "Démonstration"
            setTextColor(Color.parseColor("#475569"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f)
            val padH = dpToPx(6)
            val padV = dpToPx(3)
            setPadding(padH, padV, padH, padV)
            val bg = GradientDrawable().apply {
                setColor(Color.parseColor("#E2E8F0"))
                cornerRadius = dpToPx(4).toFloat()
            }
            background = bg
        }
        card.addView(badgeDemo)

        return card
    }

    /**
     * Dialogue permettant d'ajouter ou de modifier un produit.
     * @param productToEdit null si ajout d'un nouveau produit, sinon l'objet à modifier.
     */
    private fun openAddEditProductDialog(
        productToEdit: ProductItem?,
        parentAdminDialog: Dialog?
    ) {
        val formDialog = Dialog(this)
        formDialog.requestWindowFeature(Window.FEATURE_NO_TITLE)

        val rootScroll = ScrollView(this).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            setBackgroundColor(COLOR_BLANC)
            isVerticalScrollBarEnabled = false
        }

        val formRoot = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val pad = dpToPx(18)
            setPadding(pad, pad, pad, pad)
        }
        rootScroll.addView(formRoot)

        // 1. En-tête
        val headerLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = dpToPx(14)
            }
            layoutParams = params
        }

        val isEditMode = productToEdit != null
        val tvHeader = TextView(this).apply {
            text = if (isEditMode) "Modifier le produit" else "Ajouter un produit"
            setTextColor(COLOR_BLEU_ROI)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            val params = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            layoutParams = params
        }
        headerLayout.addView(tvHeader)

        val btnClose = TextView(this).apply {
            text = "✕"
            setTextColor(COLOR_TEXTE_SECONDAIRE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
            val padH = dpToPx(8)
            setPadding(padH, 0, padH, 0)
            isClickable = true
            isFocusable = true
            setOnClickListener { formDialog.dismiss() }
        }
        headerLayout.addView(btnClose)
        formRoot.addView(headerLayout)

        // Style standard des champs de saisie
        fun createFieldContainer(label: String): Pair<LinearLayout, TextView> {
            val container = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                val params = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply {
                    bottomMargin = dpToPx(12)
                }
                layoutParams = params
            }

            val tvLabel = TextView(this).apply {
                text = label
                setTextColor(COLOR_BLEU_ROI)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                val params = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply {
                    bottomMargin = dpToPx(4)
                }
                layoutParams = params
            }
            container.addView(tvLabel)
            return Pair(container, tvLabel)
        }

        fun createInputBackground(): GradientDrawable {
            return GradientDrawable().apply {
                setColor(COLOR_GRIS_FOND)
                cornerRadius = dpToPx(8).toFloat()
                setStroke(dpToPx(1.2f), Color.parseColor("#CBD5E1"))
            }
        }

        // Champ 1 : Nom du produit
        val (nameBox) = createFieldContainer("Nom du produit *")
        val etName = EditText(this).apply {
            hint = "Ex: Robe traditionnelle, Riz local..."
            setHintTextColor(COLOR_TEXTE_HINT)
            setTextColor(COLOR_BLEU_ROI)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            background = createInputBackground()
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            val padH = dpToPx(12)
            val padV = dpToPx(10)
            setPadding(padH, padV, padH, padV)
            if (isEditMode) {
                setText(productToEdit?.name ?: "")
            }
        }
        nameBox.addView(etName)
        formRoot.addView(nameBox)

        // Champ 2 : Prix en FCFA
        val (priceBox) = createFieldContainer("Prix en FCFA *")
        val etPrice = EditText(this).apply {
            hint = "Ex: 15000"
            setHintTextColor(COLOR_TEXTE_HINT)
            setTextColor(COLOR_BLEU_ROI)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            background = createInputBackground()
            inputType = InputType.TYPE_CLASS_NUMBER
            val padH = dpToPx(12)
            val padV = dpToPx(10)
            setPadding(padH, padV, padH, padV)
            if (isEditMode) {
                setText(productToEdit?.priceValue?.toString() ?: "")
            }
        }
        priceBox.addView(etPrice)
        formRoot.addView(priceBox)

        // Champ 3 : Catégorie
        val (categoryBox) = createFieldContainer("Catégorie *")
        val spinnerCategory = Spinner(this).apply {
            background = createInputBackground()
            val padH = dpToPx(8)
            val padV = dpToPx(8)
            setPadding(padH, padV, padH, padV)
        }
        val categoryAdapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            storeCategories
        )
        spinnerCategory.adapter = categoryAdapter
        if (isEditMode && productToEdit != null) {
            val catIdx = storeCategories.indexOf(productToEdit.category)
            if (catIdx >= 0) spinnerCategory.setSelection(catIdx)
        }
        categoryBox.addView(spinnerCategory)
        formRoot.addView(categoryBox)

        // Champ 4 : Emplacement Photo / Symbole visuel
        val (symbolBox) = createFieldContainer("Photo / Emplacement visuel *")
        val symbolLabels = availableSymbols.map { "${it.first}  ${it.second}" }
        val spinnerSymbol = Spinner(this).apply {
            background = createInputBackground()
            val padH = dpToPx(8)
            val padV = dpToPx(8)
            setPadding(padH, padV, padH, padV)
        }
        val symbolAdapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            symbolLabels
        )
        spinnerSymbol.adapter = symbolAdapter
        if (isEditMode && productToEdit != null) {
            val symIdx = availableSymbols.indexOfFirst { it.first == productToEdit.visualSymbol }
            if (symIdx >= 0) spinnerSymbol.setSelection(symIdx)
        }
        symbolBox.addView(spinnerSymbol)
        formRoot.addView(symbolBox)

        // Champ 5 : Description
        val (descBox) = createFieldContainer("Description du produit *")
        val etDesc = EditText(this).apply {
            hint = "Décrivez les caractéristiques, la qualité et l'utilité du produit..."
            setHintTextColor(COLOR_TEXTE_HINT)
            setTextColor(COLOR_BLEU_ROI)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            background = createInputBackground()
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            isSingleLine = false
            minLines = 3
            gravity = Gravity.TOP or Gravity.START
            val padH = dpToPx(12)
            val padV = dpToPx(10)
            setPadding(padH, padV, padH, padV)
            if (isEditMode) {
                setText(productToEdit?.description ?: "")
            }
        }
        descBox.addView(etDesc)
        formRoot.addView(descBox)

        // Message d'erreur dynamique
        val tvFormError = TextView(this).apply {
            setTextColor(COLOR_ROUGE_DANGER)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            visibility = View.GONE
            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = dpToPx(10)
            }
            layoutParams = params
        }
        formRoot.addView(tvFormError)

        // Boutons : Annuler / Enregistrer
        val btnRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            weightSum = 2f
            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                topMargin = dpToPx(8)
            }
            layoutParams = params
        }

        val btnCancel = Button(this).apply {
            text = "Annuler"
            setTextColor(COLOR_TEXTE_SECONDAIRE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            val bg = GradientDrawable().apply {
                setColor(COLOR_GRIS_FOND)
                cornerRadius = dpToPx(8).toFloat()
            }
            background = bg
            isAllCaps = false
            val padV = dpToPx(10)
            setPadding(0, padV, 0, padV)
            setOnClickListener { formDialog.dismiss() }
        }
        val cancelParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
            rightMargin = dpToPx(6)
        }
        btnRow.addView(btnCancel, cancelParams)

        val btnSave = Button(this).apply {
            text = if (isEditMode) "Enregistrer" else "Ajouter le produit"
            setTextColor(COLOR_BLANC)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            val bg = GradientDrawable().apply {
                setColor(COLOR_BLEU_ROI)
                cornerRadius = dpToPx(8).toFloat()
            }
            background = bg
            isAllCaps = false
            val padV = dpToPx(10)
            setPadding(0, padV, 0, padV)
        }

        btnSave.setOnClickListener {
            val name = etName.text?.toString()?.trim() ?: ""
            val priceStr = etPrice.text?.toString()?.trim() ?: ""
            val desc = etDesc.text?.toString()?.trim() ?: ""
            val cat = storeCategories[spinnerCategory.selectedItemPosition]
            val sym = availableSymbols[spinnerSymbol.selectedItemPosition].first

            if (name.isEmpty()) {
                tvFormError.text = "⚠️ Veuillez renseigner le nom du produit."
                tvFormError.visibility = View.VISIBLE
                etName.requestFocus()
                return@setOnClickListener
            }

            val priceVal = priceStr.toLongOrNull()
            if (priceVal == null || priceVal <= 0L) {
                tvFormError.text = "⚠️ Veuillez entrer un prix valide supérieur à 0 FCFA."
                tvFormError.visibility = View.VISIBLE
                etPrice.requestFocus()
                return@setOnClickListener
            }

            if (desc.isEmpty()) {
                tvFormError.text = "⚠️ Veuillez entrer une description adaptée au produit."
                tvFormError.visibility = View.VISIBLE
                etDesc.requestFocus()
                return@setOnClickListener
            }

            val formattedPrice = "${NumberFormat.getNumberInstance(Locale.FRANCE).format(priceVal)} FCFA"

            if (isEditMode && productToEdit != null) {
                // Modification du produit existant
                productToEdit.name = name
                productToEdit.priceValue = priceVal
                productToEdit.priceText = formattedPrice
                productToEdit.category = cat
                productToEdit.description = desc
                productToEdit.visualSymbol = sym

                // Mise à jour synchrone du panier si le produit y est présent
                val inCart = cartMap[productToEdit.id]
                if (inCart != null) {
                    // Les références d'objet étant partagées, les champs sont à jour
                }
                Toast.makeText(this, "Produit modifié avec succès !", Toast.LENGTH_SHORT).show()
            } else {
                // Création d'un nouveau produit personnalisé
                val nextId = (allProducts.maxOfOrNull { it.id } ?: 6) + 1
                val newProduct = ProductItem(
                    id = nextId,
                    name = name,
                    category = cat,
                    priceText = formattedPrice,
                    priceValue = priceVal,
                    description = desc,
                    visualSymbol = sym,
                    isCustom = true
                )
                allProducts.add(newProduct)
                Toast.makeText(this, "Nouveau produit ajouté à la boutique !", Toast.LENGTH_SHORT).show()
            }

            // Persistance locale
            saveCustomProductsToStorage()

            // Rafraîchissement synchrone du catalogue pour les clients
            refreshCatalogDisplay()

            formDialog.dismiss()
            parentAdminDialog?.dismiss()
            openAdminDialog() // Recharge la vue administrateur
        }

        val saveParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
            leftMargin = dpToPx(6)
        }
        btnRow.addView(btnSave, saveParams)
        formRoot.addView(btnRow)

        formDialog.setContentView(rootScroll)
        formDialog.window?.apply {
            setLayout(
                (resources.displayMetrics.widthPixels * 0.92).toInt(),
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            setBackgroundDrawableResource(android.R.color.transparent)
        }

        formDialog.show()
    }

    /**
     * Dialogue de confirmation avant la suppression définitive d'un produit.
     */
    private fun openDeleteConfirmationDialog(
        product: ProductItem,
        onDeleted: () -> Unit
    ) {
        val confirmDialog = Dialog(this)
        confirmDialog.requestWindowFeature(Window.FEATURE_NO_TITLE)

        val confirmRoot = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(COLOR_BLANC)
            val pad = dpToPx(20)
            setPadding(pad, pad, pad, pad)
            val bg = GradientDrawable().apply {
                setColor(COLOR_BLANC)
                cornerRadius = dpToPx(14).toFloat()
            }
            background = bg
        }

        // Icône danger
        val tvDangerIcon = TextView(this).apply {
            text = "⚠️"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 32f)
            gravity = Gravity.CENTER
            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = dpToPx(10)
            }
            layoutParams = params
        }
        confirmRoot.addView(tvDangerIcon)

        // Titre
        val tvConfirmTitle = TextView(this).apply {
            text = "Confirmer la suppression"
            setTextColor(COLOR_ROUGE_DANGER)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            gravity = Gravity.CENTER
            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = dpToPx(8)
            }
            layoutParams = params
        }
        confirmRoot.addView(tvConfirmTitle)

        // Message explicite
        val tvConfirmMsg = TextView(this).apply {
            text = "Êtes-vous sûr de vouloir supprimer définitivement le produit « ${product.name} » (${product.priceText}) ?\n\nCe produit sera immédiatement retiré de la boutique et du panier des clients."
            setTextColor(Color.parseColor("#334155"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            gravity = Gravity.CENTER
            setLineSpacing(dpToPx(2).toFloat(), 1f)
            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = dpToPx(20)
            }
            layoutParams = params
        }
        confirmRoot.addView(tvConfirmMsg)

        // Boutons
        val btnRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            weightSum = 2f
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        val btnCancel = Button(this).apply {
            text = "Annuler"
            setTextColor(COLOR_TEXTE_SECONDAIRE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            val bg = GradientDrawable().apply {
                setColor(COLOR_GRIS_FOND)
                cornerRadius = dpToPx(8).toFloat()
            }
            background = bg
            isAllCaps = false
            setOnClickListener { confirmDialog.dismiss() }
        }
        val cancelParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
            rightMargin = dpToPx(6)
        }
        btnRow.addView(btnCancel, cancelParams)

        val btnDelete = Button(this).apply {
            text = "Supprimer"
            setTextColor(COLOR_BLANC)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            val bg = GradientDrawable().apply {
                setColor(COLOR_ROUGE_DANGER)
                cornerRadius = dpToPx(8).toFloat()
            }
            background = bg
            isAllCaps = false
            setOnClickListener {
                allProducts.removeAll { it.id == product.id }
                if (cartMap.containsKey(product.id)) {
                    cartMap.remove(product.id)
                    updateCartBadge()
                }
                saveCustomProductsToStorage()
                refreshCatalogDisplay()
                onDeleted()
                confirmDialog.dismiss()
                Toast.makeText(this@MainActivity, "Produit « ${product.name} » supprimé.", Toast.LENGTH_SHORT).show()
            }
        }
        val deleteParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
            leftMargin = dpToPx(6)
        }
        btnRow.addView(btnDelete, deleteParams)

        confirmRoot.addView(btnRow)

        confirmDialog.setContentView(confirmRoot)
        confirmDialog.window?.apply {
            setLayout(
                (resources.displayMetrics.widthPixels * 0.88).toInt(),
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            setBackgroundDrawableResource(android.R.color.transparent)
        }

        confirmDialog.show()
    }

    // =========================================================================
    // FICHE DÉTAILLÉE PRODUIT
    // =========================================================================

    /**
     * Ouvre la fiche détaillée d'un produit sélectionné.
     */
    private fun openProductDetailDialog(product: ProductItem) {
        val detailDialog = Dialog(this)
        detailDialog.requestWindowFeature(Window.FEATURE_NO_TITLE)

        val detailRoot = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(COLOR_BLANC)
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            val pad = dpToPx(18)
            setPadding(pad, pad, pad, pad)
        }

        // 1. Barre d'en-tête avec bouton « ← Retour »
        val headerLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = dpToPx(14)
            }
            layoutParams = params
        }

        val btnBack = TextView(this).apply {
            text = "← Retour"
            setTextColor(COLOR_BLEU_ROI)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            val padH = dpToPx(10)
            val padV = dpToPx(6)
            setPadding(padH, padV, padH, padV)
            val bg = GradientDrawable().apply {
                setColor(COLOR_GRIS_FOND)
                cornerRadius = dpToPx(8).toFloat()
                setStroke(dpToPx(1f), Color.parseColor("#E2E8F0"))
            }
            background = bg
            isClickable = true
            isFocusable = true
            setOnClickListener { detailDialog.dismiss() }
        }
        headerLayout.addView(btnBack)

        val spacerHeader = View(this).apply {
            layoutParams = LinearLayout.LayoutParams(0, 1, 1f)
        }
        headerLayout.addView(spacerHeader)

        // Badge Catégorie
        val categoryBadge = TextView(this).apply {
            text = product.category
            setTextColor(COLOR_BLEU_ROI)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            val padH = dpToPx(10)
            val padV = dpToPx(5)
            setPadding(padH, padV, padH, padV)
            val bg = GradientDrawable().apply {
                setColor(Color.parseColor("#EFF6FF"))
                cornerRadius = dpToPx(12).toFloat()
                setStroke(dpToPx(1f), COLOR_BLEU_ROI)
            }
            background = bg
        }
        headerLayout.addView(categoryBadge)
        detailRoot.addView(headerLayout)

        // 2. Zone Photo propre
        val photoFrame = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            val bg = GradientDrawable().apply {
                setColor(COLOR_GRIS_FOND)
                cornerRadius = dpToPx(12).toFloat()
                setStroke(dpToPx(1.5f), Color.parseColor("#E2E8F0"))
            }
            background = bg
            val frameHeight = dpToPx(140)
            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                frameHeight
            ).apply {
                bottomMargin = dpToPx(16)
            }
            layoutParams = params
        }

        val tvSymbol = TextView(this).apply {
            text = product.visualSymbol
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 46f)
            gravity = Gravity.CENTER
        }
        photoFrame.addView(tvSymbol)

        val tvPhotoBadge = TextView(this).apply {
            text = "Photo du produit"
            setTextColor(COLOR_TEXTE_SECONDAIRE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            val padH = dpToPx(8)
            val padV = dpToPx(3)
            setPadding(padH, padV, padH, padV)
            val bg = GradientDrawable().apply {
                setColor(COLOR_BLANC)
                cornerRadius = dpToPx(6).toFloat()
                setStroke(dpToPx(1f), Color.parseColor("#CBD5E1"))
            }
            background = bg
            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                topMargin = dpToPx(6)
            }
            layoutParams = params
        }
        photoFrame.addView(tvPhotoBadge)
        detailRoot.addView(photoFrame)

        // 3. Nom du produit
        val tvDetailName = TextView(this).apply {
            text = product.name
            setTextColor(COLOR_BLEU_ROI)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = dpToPx(6)
            }
            layoutParams = params
        }
        detailRoot.addView(tvDetailName)

        // 4. Prix en FCFA
        val tvDetailPrice = TextView(this).apply {
            text = product.priceText
            setTextColor(Color.parseColor("#B45309"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = dpToPx(14)
            }
            layoutParams = params
        }
        detailRoot.addView(tvDetailPrice)

        // 5. Section Description
        val tvDescHeader = TextView(this).apply {
            text = "Description"
            setTextColor(COLOR_BLEU_ROI)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = dpToPx(4)
            }
            layoutParams = params
        }
        detailRoot.addView(tvDescHeader)

        val descBox = LinearLayout(this).apply {
            val bg = GradientDrawable().apply {
                setColor(COLOR_GRIS_FOND)
                cornerRadius = dpToPx(8).toFloat()
            }
            background = bg
            val padDesc = dpToPx(12)
            setPadding(padDesc, padDesc, padDesc, padDesc)
            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = dpToPx(18)
            }
            layoutParams = params
        }

        val tvDetailDesc = TextView(this).apply {
            text = product.description
            setTextColor(Color.parseColor("#334155"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            setLineSpacing(dpToPx(3).toFloat(), 1.0f)
        }
        descBox.addView(tvDetailDesc)
        detailRoot.addView(descBox)

        // 6. Bouton « + Ajouter au panier »
        val btnAddDetail = Button(this).apply {
            text = "+ Ajouter au panier"
            setTextColor(COLOR_BLANC)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            val bg = GradientDrawable().apply {
                setColor(COLOR_BLEU_ROI)
                cornerRadius = dpToPx(10).toFloat()
            }
            background = bg
            isAllCaps = false
            val padV = dpToPx(11)
            setPadding(dpToPx(16), padV, dpToPx(16), padV)
            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            layoutParams = params

            setOnClickListener {
                addToCart(product)
                detailDialog.dismiss()
            }
        }
        detailRoot.addView(btnAddDetail)

        detailDialog.setContentView(detailRoot)
        detailDialog.window?.apply {
            setLayout(
                (resources.displayMetrics.widthPixels * 0.90).toInt(),
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            setBackgroundDrawableResource(android.R.color.transparent)
        }

        detailDialog.show()
    }

    // =========================================================================
    // SYSTÈME DE PANIER INTERACTIF
    // =========================================================================

    /**
     * Ouvre la boîte de dialogue interactive du panier.
     */
    private fun openCartDialog() {
        val cartDialog = Dialog(this)
        cartDialog.requestWindowFeature(Window.FEATURE_NO_TITLE)

        val rootScroll = ScrollView(this).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            setBackgroundColor(COLOR_BLANC)
            isVerticalScrollBarEnabled = false
        }

        val cartRoot = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val pad = dpToPx(18)
            setPadding(pad, pad, pad, pad)
        }
        rootScroll.addView(cartRoot)

        // Barre d'en-tête du panier
        val headerLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = dpToPx(14)
            }
            layoutParams = params
        }

        val tvCartTitle = TextView(this).apply {
            text = "Mon Panier"
            setTextColor(COLOR_BLEU_ROI)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            val params = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            layoutParams = params
        }
        headerLayout.addView(tvCartTitle)

        val btnClose = TextView(this).apply {
            text = "✕"
            setTextColor(COLOR_TEXTE_SECONDAIRE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
            val padH = dpToPx(8)
            setPadding(padH, 0, padH, 0)
            isClickable = true
            isFocusable = true
            setOnClickListener { cartDialog.dismiss() }
        }
        headerLayout.addView(btnClose)
        cartRoot.addView(headerLayout)

        val itemsContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }
        cartRoot.addView(itemsContainer)

        val footerLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }
        cartRoot.addView(footerLayout)

        fun refreshCartView() {
            itemsContainer.removeAllViews()
            footerLayout.removeAllViews()

            if (cartMap.isEmpty()) {
                val emptyBox = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.CENTER
                    val padV = dpToPx(36)
                    val padH = dpToPx(16)
                    setPadding(padH, padV, padH, padV)
                    val bg = GradientDrawable().apply {
                        setColor(COLOR_GRIS_FOND)
                        cornerRadius = dpToPx(10).toFloat()
                    }
                    background = bg
                    val params = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    ).apply {
                        bottomMargin = dpToPx(12)
                    }
                    layoutParams = params
                }

                val tvEmptyIcon = TextView(this).apply {
                    text = "🛒"
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 36f)
                    gravity = Gravity.CENTER
                }
                emptyBox.addView(tvEmptyIcon)

                val tvEmpty = TextView(this).apply {
                    text = "Votre panier est vide"
                    setTextColor(COLOR_BLEU_ROI)
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
                    typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                    gravity = Gravity.CENTER
                    val params = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    ).apply {
                        topMargin = dpToPx(8)
                    }
                    layoutParams = params
                }
                emptyBox.addView(tvEmpty)

                val tvEmptySub = TextView(this).apply {
                    text = "Ajoutez des produits de Sinématiali en cliquant sur « + Ajouter au panier »."
                    setTextColor(COLOR_TEXTE_SECONDAIRE)
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                    gravity = Gravity.CENTER
                    val params = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    ).apply {
                        topMargin = dpToPx(4)
                    }
                    layoutParams = params
                }
                emptyBox.addView(tvEmptySub)

                itemsContainer.addView(emptyBox)
                return
            }

            // Affichage des articles
            for ((_, cartItem) in cartMap) {
                val itemCard = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    val padCard = dpToPx(10)
                    setPadding(padCard, padCard, padCard, padCard)
                    val bg = GradientDrawable().apply {
                        setColor(COLOR_BLANC)
                        setStroke(dpToPx(1f), Color.parseColor("#E2E8F0"))
                        cornerRadius = dpToPx(8).toFloat()
                    }
                    background = bg
                    val params = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    ).apply {
                        bottomMargin = dpToPx(8)
                    }
                    layoutParams = params
                }

                val tvSymbol = TextView(this).apply {
                    text = cartItem.product.visualSymbol
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 22f)
                    val params = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    ).apply {
                        rightMargin = dpToPx(10)
                        leftMargin = dpToPx(4)
                    }
                    layoutParams = params
                }
                itemCard.addView(tvSymbol)

                val infoCol = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    val params = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                        rightMargin = dpToPx(8)
                    }
                    layoutParams = params
                }

                val tvItemName = TextView(this).apply {
                    text = cartItem.product.name
                    setTextColor(COLOR_BLEU_ROI)
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
                    typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                }
                infoCol.addView(tvItemName)

                val tvItemPrice = TextView(this).apply {
                    text = cartItem.product.priceText
                    setTextColor(Color.parseColor("#B45309"))
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                    typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                }
                infoCol.addView(tvItemPrice)
                itemCard.addView(infoCol)

                // Contrôles quantité : [-] [qté] [+] [🗑]
                val qtyControls = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                }

                val btnMinus = createSmallButton("-") {
                    if (cartItem.quantity > 1) {
                        cartItem.quantity -= 1
                    } else {
                        cartMap.remove(cartItem.product.id)
                    }
                    updateCartBadge()
                    refreshCartView()
                }
                qtyControls.addView(btnMinus)

                val tvQty = TextView(this).apply {
                    text = cartItem.quantity.toString()
                    setTextColor(COLOR_BLEU_ROI)
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
                    typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                    val padH = dpToPx(8)
                    setPadding(padH, 0, padH, 0)
                }
                qtyControls.addView(tvQty)

                val btnPlus = createSmallButton("+") {
                    cartItem.quantity += 1
                    updateCartBadge()
                    refreshCartView()
                }
                qtyControls.addView(btnPlus)

                val btnTrash = createSmallButton("🗑") {
                    cartMap.remove(cartItem.product.id)
                    updateCartBadge()
                    refreshCartView()
                }
                val trashParams = LinearLayout.LayoutParams(dpToPx(28), dpToPx(28)).apply {
                    leftMargin = dpToPx(6)
                }
                qtyControls.addView(btnTrash, trashParams)

                itemCard.addView(qtyControls)
                itemsContainer.addView(itemCard)
            }

            // Total et bouton « Passer la commande »
            val totalAmount = cartMap.values.sumOf { it.product.priceValue * it.quantity }
            val formattedTotal = "${NumberFormat.getNumberInstance(Locale.FRANCE).format(totalAmount)} FCFA"

            val divider = View(this).apply {
                val bg = GradientDrawable().apply {
                    setColor(Color.parseColor("#CBD5E1"))
                }
                background = bg
                val params = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    dpToPx(1)
                ).apply {
                    topMargin = dpToPx(12)
                    bottomMargin = dpToPx(12)
                }
                layoutParams = params
            }
            footerLayout.addView(divider)

            val totalRow = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                val params = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply {
                    bottomMargin = dpToPx(14)
                }
                layoutParams = params
            }

            val tvTotalLabel = TextView(this).apply {
                text = "Total à régler :"
                setTextColor(COLOR_BLEU_ROI)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                val params = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                layoutParams = params
            }
            totalRow.addView(tvTotalLabel)

            val tvTotalValue = TextView(this).apply {
                text = formattedTotal
                setTextColor(Color.parseColor("#B45309"))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            }
            totalRow.addView(tvTotalValue)
            footerLayout.addView(totalRow)

            val btnCheckout = Button(this).apply {
                text = "Passer la commande"
                setTextColor(COLOR_BLANC)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                val bg = GradientDrawable().apply {
                    setColor(COLOR_BLEU_ROI)
                    cornerRadius = dpToPx(10).toFloat()
                }
                background = bg
                isAllCaps = false
                val padV = dpToPx(11)
                setPadding(dpToPx(16), padV, dpToPx(16), padV)
                val params = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
                layoutParams = params

                setOnClickListener {
                    cartDialog.dismiss()
                    openDeliveryDialog()
                }
            }
            footerLayout.addView(btnCheckout)
        }

        refreshCartView()

        cartDialog.setContentView(rootScroll)
        cartDialog.window?.apply {
            setLayout(
                (resources.displayMetrics.widthPixels * 0.92).toInt(),
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            setBackgroundDrawableResource(android.R.color.transparent)
        }

        cartDialog.show()
    }

    // =========================================================================
    // FORMULAIRE DE LIVRAISON & CONFIRMATION
    // =========================================================================

    /**
     * Ouvre le formulaire de livraison accessible depuis le panier.
     */
    private fun openDeliveryDialog() {
        val deliveryDialog = Dialog(this)
        deliveryDialog.requestWindowFeature(Window.FEATURE_NO_TITLE)

        val rootScroll = ScrollView(this).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            setBackgroundColor(COLOR_BLANC)
            isVerticalScrollBarEnabled = false
        }

        val deliveryRoot = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val pad = dpToPx(18)
            setPadding(pad, pad, pad, pad)
        }
        rootScroll.addView(deliveryRoot)

        // 1. Barre d'en-tête avec bouton « ← Retour au panier »
        val headerLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = dpToPx(14)
            }
            layoutParams = params
        }

        val btnBackToCart = TextView(this).apply {
            text = "← Panier"
            setTextColor(COLOR_BLEU_ROI)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            val padH = dpToPx(10)
            val padV = dpToPx(6)
            setPadding(padH, padV, padH, padV)
            val bg = GradientDrawable().apply {
                setColor(COLOR_GRIS_FOND)
                cornerRadius = dpToPx(8).toFloat()
                setStroke(dpToPx(1f), Color.parseColor("#E2E8F0"))
            }
            background = bg
            isClickable = true
            isFocusable = true
            setOnClickListener {
                deliveryDialog.dismiss()
                openCartDialog()
            }
        }
        headerLayout.addView(btnBackToCart)

        val spacerHeader = View(this).apply {
            layoutParams = LinearLayout.LayoutParams(0, 1, 1f)
        }
        headerLayout.addView(spacerHeader)

        val tvFormTitle = TextView(this).apply {
            text = "Informations de livraison"
            setTextColor(COLOR_BLEU_ROI)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        headerLayout.addView(tvFormTitle)
        deliveryRoot.addView(headerLayout)

        // 2. Encadré Récapitulatif rapide de la commande
        val summaryCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val bg = GradientDrawable().apply {
                setColor(Color.parseColor("#EFF6FF"))
                setStroke(dpToPx(1f), COLOR_BLEU_ROI)
                cornerRadius = dpToPx(10).toFloat()
            }
            background = bg
            val padCard = dpToPx(12)
            setPadding(padCard, padCard, padCard, padCard)
            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = dpToPx(16)
            }
            layoutParams = params
        }

        val tvSummaryHeader = TextView(this).apply {
            text = "Récapitulatif de votre commande"
            setTextColor(COLOR_BLEU_ROI)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = dpToPx(6)
            }
            layoutParams = params
        }
        summaryCard.addView(tvSummaryHeader)

        for ((_, cartItem) in cartMap) {
            val itemLine = TextView(this).apply {
                text = "• ${cartItem.product.name} (x${cartItem.quantity}) — ${NumberFormat.getNumberInstance(Locale.FRANCE).format(cartItem.product.priceValue * cartItem.quantity)} FCFA"
                setTextColor(Color.parseColor("#334155"))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                val params = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply {
                    bottomMargin = dpToPx(2)
                }
                layoutParams = params
            }
            summaryCard.addView(itemLine)
        }

        val totalAmount = cartMap.values.sumOf { it.product.priceValue * it.quantity }
        val tvSummaryTotal = TextView(this).apply {
            text = "Montant total : ${NumberFormat.getNumberInstance(Locale.FRANCE).format(totalAmount)} FCFA"
            setTextColor(Color.parseColor("#B45309"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                topMargin = dpToPx(6)
            }
            layoutParams = params
        }
        summaryCard.addView(tvSummaryTotal)
        deliveryRoot.addView(summaryCard)

        // 3. Champs du formulaire avec bordures propres
        fun createFieldContainer(label: String): Pair<LinearLayout, TextView> {
            val container = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                val params = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply {
                    bottomMargin = dpToPx(12)
                }
                layoutParams = params
            }

            val tvLabel = TextView(this).apply {
                text = label
                setTextColor(COLOR_BLEU_ROI)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                val params = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply {
                    bottomMargin = dpToPx(4)
                }
                layoutParams = params
            }
            container.addView(tvLabel)
            return Pair(container, tvLabel)
        }

        fun createInputBackground(): GradientDrawable {
            return GradientDrawable().apply {
                setColor(COLOR_GRIS_FOND)
                cornerRadius = dpToPx(8).toFloat()
                setStroke(dpToPx(1.2f), Color.parseColor("#CBD5E1"))
            }
        }

        // Champ 1 : Nom et prénom
        val (nameContainer) = createFieldContainer("Nom et prénom du client *")
        val etName = EditText(this).apply {
            hint = "Ex: Soro Amadou, Koné Fatou..."
            setHintTextColor(COLOR_TEXTE_HINT)
            setTextColor(COLOR_BLEU_ROI)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            background = createInputBackground()
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_WORDS
            val padH = dpToPx(12)
            val padV = dpToPx(10)
            setPadding(padH, padV, padH, padV)
            setText(savedClientName)
        }
        nameContainer.addView(etName)
        deliveryRoot.addView(nameContainer)

        // Champ 2 : Numéro de téléphone
        val (phoneContainer) = createFieldContainer("Numéro de téléphone *")
        val etPhone = EditText(this).apply {
            hint = "Ex: 07 01 02 03 04 ou 05 00 11 22 33"
            setHintTextColor(COLOR_TEXTE_HINT)
            setTextColor(COLOR_BLEU_ROI)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            background = createInputBackground()
            inputType = InputType.TYPE_CLASS_PHONE
            val padH = dpToPx(12)
            val padV = dpToPx(10)
            setPadding(padH, padV, padH, padV)
            setText(savedClientPhone)
        }
        phoneContainer.addView(etPhone)
        deliveryRoot.addView(phoneContainer)

        // Champ 3 : Ville de livraison (Spinner des villes de Côte d'Ivoire)
        val (cityContainer) = createFieldContainer("Ville de livraison (Côte d'Ivoire) *")
        val spinnerCity = Spinner(this).apply {
            background = createInputBackground()
            val padH = dpToPx(8)
            val padV = dpToPx(8)
            setPadding(padH, padV, padH, padV)
        }
        val cityAdapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            ivorianCities
        )
        spinnerCity.adapter = cityAdapter
        spinnerCity.setSelection(savedClientCityIndex)
        cityContainer.addView(spinnerCity)
        deliveryRoot.addView(cityContainer)

        // Champ 4 : Quartier de livraison
        val (districtContainer) = createFieldContainer("Quartier de livraison *")
        val etDistrict = EditText(this).apply {
            hint = "Ex: Centre-ville, Sokoura, Résidentiel..."
            setHintTextColor(COLOR_TEXTE_HINT)
            setTextColor(COLOR_BLEU_ROI)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            background = createInputBackground()
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_WORDS
            val padH = dpToPx(12)
            val padV = dpToPx(10)
            setPadding(padH, padV, padH, padV)
            setText(savedClientDistrict)
        }
        districtContainer.addView(etDistrict)
        deliveryRoot.addView(districtContainer)

        // Zone d'erreur de validation
        val tvErrorMessage = TextView(this).apply {
            setTextColor(COLOR_ROUGE_DANGER)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            visibility = View.GONE
            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = dpToPx(10)
            }
            layoutParams = params
        }
        deliveryRoot.addView(tvErrorMessage)

        // 4. Bouton « Continuer »
        val btnContinue = Button(this).apply {
            text = "Continuer"
            setTextColor(COLOR_BLANC)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            val bg = GradientDrawable().apply {
                setColor(COLOR_BLEU_ROI)
                cornerRadius = dpToPx(10).toFloat()
            }
            background = bg
            isAllCaps = false
            val padV = dpToPx(11)
            setPadding(dpToPx(16), padV, dpToPx(16), padV)
            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            layoutParams = params

            setOnClickListener {
                val inputName = etName.text?.toString()?.trim() ?: ""
                val inputPhone = etPhone.text?.toString()?.trim() ?: ""
                val inputDistrict = etDistrict.text?.toString()?.trim() ?: ""
                val selectedCityIndex = spinnerCity.selectedItemPosition
                val selectedCity = ivorianCities.getOrElse(selectedCityIndex) { "Sinématiali" }

                // Contrôles pour empêcher de continuer si un champ requis est vide
                if (inputName.isEmpty()) {
                    tvErrorMessage.text = "⚠️ Veuillez saisir votre nom et prénom."
                    tvErrorMessage.visibility = View.VISIBLE
                    etName.requestFocus()
                    return@setOnClickListener
                }

                if (inputPhone.isEmpty()) {
                    tvErrorMessage.text = "⚠️ Veuillez renseigner votre numéro de téléphone."
                    tvErrorMessage.visibility = View.VISIBLE
                    etPhone.requestFocus()
                    return@setOnClickListener
                }

                if (selectedCity.isEmpty()) {
                    tvErrorMessage.text = "⚠️ Veuillez sélectionner une ville de livraison."
                    tvErrorMessage.visibility = View.VISIBLE
                    return@setOnClickListener
                }

                if (inputDistrict.isEmpty()) {
                    tvErrorMessage.text = "⚠️ Veuillez indiquer votre quartier de livraison."
                    tvErrorMessage.visibility = View.VISIBLE
                    etDistrict.requestFocus()
                    return@setOnClickListener
                }

                // Sauvegarde des informations saisies pour ne rien perdre
                savedClientName = inputName
                savedClientPhone = inputPhone
                savedClientCityIndex = selectedCityIndex
                savedClientDistrict = inputDistrict

                deliveryDialog.dismiss()
                openOrderConfirmationDialog(
                    clientName = inputName,
                    clientPhone = inputPhone,
                    clientCity = selectedCity,
                    clientDistrict = inputDistrict
                )
            }
        }
        deliveryRoot.addView(btnContinue)

        deliveryDialog.setContentView(rootScroll)
        deliveryDialog.window?.apply {
            setLayout(
                (resources.displayMetrics.widthPixels * 0.92).toInt(),
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            setBackgroundDrawableResource(android.R.color.transparent)
        }

        deliveryDialog.show()
    }

    /**
     * Ouvre l'écran de confirmation de commande après le formulaire de livraison.
     */
    private fun openOrderConfirmationDialog(
        clientName: String,
        clientPhone: String,
        clientCity: String,
        clientDistrict: String
    ) {
        val confirmDialog = Dialog(this)
        confirmDialog.requestWindowFeature(Window.FEATURE_NO_TITLE)

        val rootScroll = ScrollView(this).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            setBackgroundColor(COLOR_BLANC)
            isVerticalScrollBarEnabled = false
        }

        val confirmRoot = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val pad = dpToPx(18)
            setPadding(pad, pad, pad, pad)
        }
        rootScroll.addView(confirmRoot)

        // 1. Barre d'en-tête
        val headerLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = dpToPx(14)
            }
            layoutParams = params
        }

        val tvConfirmHeader = TextView(this).apply {
            text = "Confirmation de la commande"
            setTextColor(COLOR_BLEU_ROI)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            val params = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            layoutParams = params
        }
        headerLayout.addView(tvConfirmHeader)

        val btnClose = TextView(this).apply {
            text = "✕"
            setTextColor(COLOR_TEXTE_SECONDAIRE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
            val padH = dpToPx(8)
            setPadding(padH, 0, padH, 0)
            isClickable = true
            isFocusable = true
            setOnClickListener { confirmDialog.dismiss() }
        }
        headerLayout.addView(btnClose)
        confirmRoot.addView(headerLayout)

        // 2. Récapitulatif détaillé des produits commandés
        val productsCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val bg = GradientDrawable().apply {
                setColor(COLOR_BLANC)
                setStroke(dpToPx(1f), Color.parseColor("#E2E8F0"))
                cornerRadius = dpToPx(10).toFloat()
            }
            background = bg
            val padCard = dpToPx(12)
            setPadding(padCard, padCard, padCard, padCard)
            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = dpToPx(14)
            }
            layoutParams = params
        }

        val tvProductsTitle = TextView(this).apply {
            text = "Articles commandés"
            setTextColor(COLOR_BLEU_ROI)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = dpToPx(8)
            }
            layoutParams = params
        }
        productsCard.addView(tvProductsTitle)

        var calculatedTotal = 0L
        for ((_, cartItem) in cartMap) {
            val subTotal = cartItem.product.priceValue * cartItem.quantity
            calculatedTotal += subTotal

            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                val params = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply {
                    bottomMargin = dpToPx(6)
                }
                layoutParams = params
            }

            val tvItemDesc = TextView(this).apply {
                text = "${cartItem.product.visualSymbol} ${cartItem.product.name} (x${cartItem.quantity})"
                setTextColor(Color.parseColor("#1E293B"))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                val params = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                layoutParams = params
            }
            row.addView(tvItemDesc)

            val tvItemTotal = TextView(this).apply {
                text = "${NumberFormat.getNumberInstance(Locale.FRANCE).format(subTotal)} FCFA"
                setTextColor(Color.parseColor("#B45309"))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            }
            row.addView(tvItemTotal)

            productsCard.addView(row)
        }

        val divider = View(this).apply {
            val bg = GradientDrawable().apply {
                setColor(Color.parseColor("#E2E8F0"))
            }
            background = bg
            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dpToPx(1)
            ).apply {
                topMargin = dpToPx(6)
                bottomMargin = dpToPx(8)
            }
            layoutParams = params
        }
        productsCard.addView(divider)

        // Montant total en FCFA
        val totalRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        val tvTotalLabel = TextView(this).apply {
            text = "Montant total en FCFA :"
            setTextColor(COLOR_BLEU_ROI)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            val params = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            layoutParams = params
        }
        totalRow.addView(tvTotalLabel)

        val tvTotalFormatted = TextView(this).apply {
            text = "${NumberFormat.getNumberInstance(Locale.FRANCE).format(calculatedTotal)} FCFA"
            setTextColor(Color.parseColor("#B45309"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        totalRow.addView(tvTotalFormatted)
        productsCard.addView(totalRow)

        confirmRoot.addView(productsCard)

        // 3. Récapitulatif des coordonnées de livraison du client
        val clientCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val bg = GradientDrawable().apply {
                setColor(Color.parseColor("#EFF6FF"))
                setStroke(dpToPx(1f), COLOR_BLEU_ROI)
                cornerRadius = dpToPx(10).toFloat()
            }
            background = bg
            val padCard = dpToPx(12)
            setPadding(padCard, padCard, padCard, padCard)
            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = dpToPx(16)
            }
            layoutParams = params
        }

        val tvClientHeader = TextView(this).apply {
            text = "Coordonnées de livraison"
            setTextColor(COLOR_BLEU_ROI)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = dpToPx(6)
            }
            layoutParams = params
        }
        clientCard.addView(tvClientHeader)

        fun addInfoRow(icon: String, label: String, value: String) {
            val tv = TextView(this).apply {
                text = "$icon $label : $value"
                setTextColor(Color.parseColor("#334155"))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                val params = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply {
                    bottomMargin = dpToPx(3)
                }
                layoutParams = params
            }
            clientCard.addView(tv)
        }

        addInfoRow("👤", "Client", clientName)
        addInfoRow("📞", "Téléphone", clientPhone)
        addInfoRow("📍", "Ville", clientCity)
        addInfoRow("🏡", "Quartier", clientDistrict)

        confirmRoot.addView(clientCard)

        // 4. Bouton « Modifier mes informations »
        val btnModify = Button(this).apply {
            text = "Modifier mes informations"
            setTextColor(COLOR_BLEU_ROI)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            val bg = GradientDrawable().apply {
                setColor(COLOR_GRIS_FOND)
                cornerRadius = dpToPx(8).toFloat()
                setStroke(dpToPx(1.2f), COLOR_BLEU_ROI)
            }
            background = bg
            isAllCaps = false
            val padV = dpToPx(10)
            setPadding(dpToPx(16), padV, dpToPx(16), padV)
            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = dpToPx(10)
            }
            layoutParams = params

            setOnClickListener {
                confirmDialog.dismiss()
                openDeliveryDialog()
            }
        }
        confirmRoot.addView(btnModify)

        // 5. Bouton « Confirmer la commande »
        val btnConfirmOrder = Button(this).apply {
            text = "Confirmer la commande"
            setTextColor(COLOR_BLANC)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            val bg = GradientDrawable().apply {
                setColor(COLOR_BLEU_ROI)
                cornerRadius = dpToPx(10).toFloat()
            }
            background = bg
            isAllCaps = false
            val padV = dpToPx(11)
            setPadding(dpToPx(16), padV, dpToPx(16), padV)
            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            layoutParams = params

            setOnClickListener {
                saveConfirmedOrder(
                    clientName = clientName,
                    clientPhone = clientPhone,
                    clientCity = clientCity,
                    clientDistrict = clientDistrict
                )
                confirmDialog.dismiss()
                showOrderSuccessDialog()
            }
        }
        confirmRoot.addView(btnConfirmOrder)

        confirmDialog.setContentView(rootScroll)
        confirmDialog.window?.apply {
            setLayout(
                (resources.displayMetrics.widthPixels * 0.92).toInt(),
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            setBackgroundDrawableResource(android.R.color.transparent)
        }

        confirmDialog.show()
    }

    /**
     * Affiche l'écran de notification finale avec le message officiel :
     * « Votre commande est enregistrée sur cet appareil. Le vendeur doit encore la recevoir pour la traiter. »
     */
    private fun showOrderSuccessDialog() {
        val successDialog = Dialog(this)
        successDialog.requestWindowFeature(Window.FEATURE_NO_TITLE)

        val successRoot = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(COLOR_BLANC)
            gravity = Gravity.CENTER_HORIZONTAL
            val pad = dpToPx(22)
            setPadding(pad, pad, pad, pad)
            val bg = GradientDrawable().apply {
                setColor(COLOR_BLANC)
                cornerRadius = dpToPx(14).toFloat()
            }
            background = bg
        }

        // Icône de validation
        val tvSuccessIcon = TextView(this).apply {
            text = "✓"
            setTextColor(COLOR_BLANC)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 28f)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            gravity = Gravity.CENTER
            val circleBg = GradientDrawable().apply {
                setColor(Color.parseColor("#16A34A"))
                shape = GradientDrawable.OVAL
            }
            background = circleBg
            val size = dpToPx(56)
            val params = LinearLayout.LayoutParams(size, size).apply {
                bottomMargin = dpToPx(14)
            }
            layoutParams = params
        }
        successRoot.addView(tvSuccessIcon)

        // Titre de confirmation
        val tvSuccessTitle = TextView(this).apply {
            text = "Commande enregistrée !"
            setTextColor(COLOR_BLEU_ROI)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            gravity = Gravity.CENTER
            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = dpToPx(12)
            }
            layoutParams = params
        }
        successRoot.addView(tvSuccessTitle)

        // Encadré contenant le message officiel
        val noticeBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val bg = GradientDrawable().apply {
                setColor(COLOR_GRIS_FOND)
                cornerRadius = dpToPx(10).toFloat()
                setStroke(dpToPx(1f), Color.parseColor("#E2E8F0"))
            }
            background = bg
            val padNotice = dpToPx(14)
            setPadding(padNotice, padNotice, padNotice, padNotice)
            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = dpToPx(18)
            }
            layoutParams = params
        }

        // Message textuel exact
        val tvOfficialNotice = TextView(this).apply {
            text = "Votre commande est enregistrée sur cet appareil. Le vendeur doit encore la recevoir pour la traiter."
            setTextColor(Color.parseColor("#1E293B"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            gravity = Gravity.CENTER
            setLineSpacing(dpToPx(3).toFloat(), 1.0f)
        }
        noticeBox.addView(tvOfficialNotice)
        successRoot.addView(noticeBox)

        // Bouton « Retour à l'accueil »
        val btnBackHome = Button(this).apply {
            text = "Retour à l'accueil"
            setTextColor(COLOR_BLANC)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            val bg = GradientDrawable().apply {
                setColor(COLOR_BLEU_ROI)
                cornerRadius = dpToPx(10).toFloat()
            }
            background = bg
            isAllCaps = false
            val padV = dpToPx(11)
            setPadding(dpToPx(16), padV, dpToPx(16), padV)
            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            layoutParams = params

            setOnClickListener {
                cartMap.clear()
                updateCartBadge()
                successDialog.dismiss()
            }
        }
        successRoot.addView(btnBackHome)

        successDialog.setContentView(successRoot)
        successDialog.window?.apply {
            setLayout(
                (resources.displayMetrics.widthPixels * 0.92).toInt(),
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            setBackgroundDrawableResource(android.R.color.transparent)
        }

        successDialog.show()
    }

    // =========================================================================
    // RENDU DU CATALOGUE ET COMPOSANTS UI
    // =========================================================================

    /**
     * Met à jour le compteur du panier affiché dans l'en-tête.
     */
    private fun updateCartBadge() {
        val totalCount = cartMap.values.sumOf { it.quantity }
        tvCartBadge.text = "Panier ($totalCount)"
    }

    /**
     * Ajoute un produit au panier et affiche une confirmation discrète.
     */
    private fun addToCart(product: ProductItem) {
        val existing = cartMap[product.id]
        if (existing != null) {
            existing.quantity += 1
        } else {
            cartMap[product.id] = CartItem(product = product, quantity = 1)
        }
        updateCartBadge()
        Toast.makeText(this, "${product.name} ajouté au panier", Toast.LENGTH_SHORT).show()
    }

    /**
     * Crée un petit bouton carré (+ / - / 🗑) pour le panier.
     */
    private fun createSmallButton(label: String, onClick: () -> Unit): TextView {
        return TextView(this).apply {
            text = label
            setTextColor(COLOR_BLEU_ROI)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            gravity = Gravity.CENTER
            val size = dpToPx(28)
            layoutParams = LinearLayout.LayoutParams(size, size)
            val bg = GradientDrawable().apply {
                setColor(COLOR_GRIS_FOND)
                cornerRadius = dpToPx(6).toFloat()
                setStroke(dpToPx(1f), Color.parseColor("#CBD5E1"))
            }
            background = bg
            isClickable = true
            isFocusable = true
            setOnClickListener { onClick() }
        }
    }

    /**
     * Affiche dynamiquement les produits filtrés dans la grille à deux colonnes.
     */
    private fun renderProducts(products: List<ProductItem>) {
        productsContainer.removeAllViews()

        if (products.isEmpty()) {
            val emptyContainer = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                val padV = dpToPx(36)
                val padH = dpToPx(16)
                setPadding(padH, padV, padH, padV)
                val bg = GradientDrawable().apply {
                    setColor(COLOR_GRIS_FOND)
                    cornerRadius = dpToPx(12).toFloat()
                    setStroke(dpToPx(1f), Color.parseColor("#E2E8F0"))
                }
                background = bg
                val params = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply {
                    bottomMargin = dpToPx(16)
                }
                layoutParams = params
            }

            val tvEmpty = TextView(this).apply {
                text = "Aucun produit trouvé"
                setTextColor(COLOR_TEXTE_SECONDAIRE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                gravity = Gravity.CENTER
            }
            emptyContainer.addView(tvEmpty)

            productsContainer.addView(emptyContainer)
            return
        }

        val spacingPx = dpToPx(12)

        for (i in products.indices step 2) {
            val productRow = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                weightSum = 2f
                val params = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply {
                    bottomMargin = spacingPx
                }
                layoutParams = params
            }

            val productCardLeft = createProductCard(products[i])
            val pLeftParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                rightMargin = spacingPx / 2
            }
            productRow.addView(productCardLeft, pLeftParams)

            if (i + 1 < products.size) {
                val productCardRight = createProductCard(products[i + 1])
                val pRightParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                    leftMargin = spacingPx / 2
                }
                productRow.addView(productCardRight, pRightParams)
            } else {
                val emptySpacer = View(this).apply {
                    val params = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f).apply {
                        leftMargin = spacingPx / 2
                    }
                    layoutParams = params
                }
                productRow.addView(emptySpacer)
            }

            productsContainer.addView(productRow)
        }
    }

    /**
     * Crée un en-tête de section avec indicateur doré (#FFD700).
     */
    private fun createSectionHeader(title: String): View {
        val headerLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = dpToPx(12)
            }
            layoutParams = params
        }

        val goldIndicator = View(this).apply {
            val bg = GradientDrawable().apply {
                setColor(COLOR_OR_PACHA)
                cornerRadius = dpToPx(2).toFloat()
            }
            background = bg
            layoutParams = LinearLayout.LayoutParams(dpToPx(4), dpToPx(18)).apply {
                rightMargin = dpToPx(8)
            }
        }
        headerLayout.addView(goldIndicator)

        val tvTitle = TextView(this).apply {
            text = title
            setTextColor(COLOR_BLEU_ROI)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        headerLayout.addView(tvTitle)

        return headerLayout
    }

    /**
     * Crée une carte de catégorie (2 colonnes).
     */
    private fun createCategoryCard(name: String): View {
        val cardBackground = GradientDrawable().apply {
            setColor(COLOR_BLANC)
            setStroke(dpToPx(1.5f), COLOR_BLEU_ROI)
            cornerRadius = dpToPx(14).toFloat()
        }

        val cardLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = cardBackground
            val padH = dpToPx(10)
            val padV = dpToPx(16)
            setPadding(padH, padV, padH, padV)
            isClickable = true
            isFocusable = true
            minimumHeight = dpToPx(72)

            setOnClickListener {
                Toast.makeText(this@MainActivity, "Catégorie : $name", Toast.LENGTH_SHORT).show()
            }
        }

        val dotAccent = View(this).apply {
            val dotBg = GradientDrawable().apply {
                setColor(COLOR_OR_PACHA)
                shape = GradientDrawable.OVAL
            }
            background = dotBg
            val size = dpToPx(6)
            val params = LinearLayout.LayoutParams(size, size).apply {
                bottomMargin = dpToPx(6)
            }
            layoutParams = params
        }
        cardLayout.addView(dotAccent)

        val tvName = TextView(this).apply {
            text = name
            setTextColor(COLOR_BLEU_ROI)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            gravity = Gravity.CENTER
            maxLines = 1
        }
        cardLayout.addView(tvName)

        return cardLayout
    }

    /**
     * Crée une carte de produit complète.
     */
    private fun createProductCard(product: ProductItem): View {
        val cardBackground = GradientDrawable().apply {
            setColor(COLOR_BLANC)
            setStroke(dpToPx(1.5f), COLOR_BLEU_ROI)
            cornerRadius = dpToPx(14).toFloat()
        }

        val cardLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = cardBackground
            val pad = dpToPx(12)
            setPadding(pad, pad, pad, pad)
            gravity = Gravity.CENTER_HORIZONTAL
            isClickable = true
            isFocusable = true
        }

        // Emplacement photo
        val photoPlaceholder = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            val phBg = GradientDrawable().apply {
                setColor(COLOR_GRIS_FOND)
                cornerRadius = dpToPx(10).toFloat()
            }
            background = phBg
            val size = dpToPx(72)
            val params = LinearLayout.LayoutParams(size, size).apply {
                bottomMargin = dpToPx(8)
            }
            layoutParams = params
            isClickable = true
            isFocusable = true
            setOnClickListener {
                openProductDetailDialog(product)
            }
        }

        val tvSymbol = TextView(this).apply {
            text = product.visualSymbol
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 32f)
            gravity = Gravity.CENTER
        }
        photoPlaceholder.addView(tvSymbol)
        cardLayout.addView(photoPlaceholder)

        // Badge Catégorie
        val badgeCategory = TextView(this).apply {
            text = product.category
            setTextColor(COLOR_BLEU_ROI)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            val padH = dpToPx(6)
            val padV = dpToPx(2)
            setPadding(padH, padV, padH, padV)
            val bg = GradientDrawable().apply {
                setColor(Color.parseColor("#EFF6FF"))
                cornerRadius = dpToPx(4).toFloat()
            }
            background = bg
            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = dpToPx(4)
            }
            layoutParams = params
            isClickable = true
            isFocusable = true
            setOnClickListener {
                openProductDetailDialog(product)
            }
        }
        cardLayout.addView(badgeCategory)

        // Nom du produit
        val tvName = TextView(this).apply {
            text = product.name
            setTextColor(COLOR_BLEU_ROI)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            gravity = Gravity.CENTER
            maxLines = 2
            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = dpToPx(4)
            }
            layoutParams = params
        }
        cardLayout.addView(tvName)

        // Prix en FCFA
        val tvPrice = TextView(this).apply {
            text = product.priceText
            setTextColor(Color.parseColor("#B45309"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            gravity = Gravity.CENTER
            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = dpToPx(8)
            }
            layoutParams = params
        }
        cardLayout.addView(tvPrice)

        // Bouton « Voir le produit »
        val btnViewBg = GradientDrawable().apply {
            setColor(COLOR_GRIS_FOND)
            cornerRadius = dpToPx(8).toFloat()
            setStroke(dpToPx(1.2f), COLOR_BLEU_ROI)
        }

        val btnViewProduct = Button(this).apply {
            text = "Voir le produit"
            setTextColor(COLOR_BLEU_ROI)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            background = btnViewBg
            isAllCaps = false
            val btnPadV = dpToPx(5)
            setPadding(dpToPx(4), btnPadV, dpToPx(4), btnPadV)
            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dpToPx(34)
            ).apply {
                bottomMargin = dpToPx(6)
            }
            layoutParams = params

            setOnClickListener {
                openProductDetailDialog(product)
            }
        }
        cardLayout.addView(btnViewProduct)

        // Bouton « + Ajouter au panier »
        val btnAddBg = GradientDrawable().apply {
            setColor(COLOR_BLEU_ROI)
            cornerRadius = dpToPx(8).toFloat()
        }

        val btnAddToCart = Button(this).apply {
            text = "+ Ajouter au panier"
            setTextColor(COLOR_BLANC)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            background = btnAddBg
            isAllCaps = false
            val btnPadV = dpToPx(5)
            setPadding(dpToPx(4), btnPadV, dpToPx(4), btnPadV)
            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dpToPx(34)
            )
            layoutParams = params

            setOnClickListener {
                addToCart(product)
            }
        }
        cardLayout.addView(btnAddToCart)

        return cardLayout
    }

    private fun dpToPx(dp: Int): Int {
        return (dp * resources.displayMetrics.density).toInt()
    }

    private fun dpToPx(dp: Float): Int {
        return (dp * resources.displayMetrics.density).toInt()
    }
}
