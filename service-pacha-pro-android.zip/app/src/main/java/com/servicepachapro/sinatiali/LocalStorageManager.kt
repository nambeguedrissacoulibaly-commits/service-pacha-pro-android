package com.servicepachapro.sinatiali

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Article commandé au sein d'une commande enregistrée.
 */
data class OrderItemRecord(
    val productId: Int,
    val productName: String,
    val unitPrice: Long,
    val quantity: Int,
    val subtotal: Long
)

/**
 * Commande enregistrée localement sur l'appareil du commerçant/client.
 *
 * Toutes les données restent sauvegardées dans la mémoire locale privée (SharedPreferences).
 * Aucun serveur distant n'étant connecté, la persistance est garantie sur l'appareil.
 */
data class OrderRecord(
    val id: String,
    val timestamp: Long,
    val dateFormatted: String,
    val clientName: String,
    val clientPhone: String,
    val clientCity: String,
    val clientDistrict: String,
    val totalAmount: Long,
    val items: List<OrderItemRecord>
)

/**
 * LocalStorageManager - Gestionnaire de persistance locale pour SERVICE PACHA PRO.
 *
 * Fonctionnalités garanties :
 * 1. Sauvegarde et restauration durable des produits ajoutés par l'administrateur.
 * 2. Sauvegarde et restauration durable des commandes confirmées par les clients.
 * 3. Prévention stricte des doublons (par ID unique de produit et de commande).
 * 4. Préservation inaltérée des 6 produits de démonstration natifs.
 * 5. Zéro dépendance Gradle supplémentaire : utilise le stockage natif sécurisé d'Android.
 */
class LocalStorageManager(private val context: Context) {

    companion object {
        private const val PREFS_NAME = "pacha_pro_local_store"
        private const val KEY_CUSTOM_PRODUCTS = "key_custom_products_json"
        private const val KEY_CONFIRMED_ORDERS = "key_confirmed_orders_json"
    }

    private val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    // =========================================================================
    // GESTION DES PRODUITS PERSONNALISÉS
    // =========================================================================

    /**
     * Enregistre la liste des produits personnalisés de l'administrateur.
     * Évite les doublons en filtrant par ID unique.
     */
    fun saveCustomProducts(products: List<MainActivity.ProductItem>) {
        val uniqueProducts = products.filter { it.isCustom }.distinctBy { it.id }
        val array = JSONArray()

        for (item in uniqueProducts) {
            val obj = JSONObject().apply {
                put("id", item.id)
                put("name", item.name)
                put("category", item.category)
                put("priceText", item.priceText)
                put("priceValue", item.priceValue)
                put("description", item.description)
                put("visualSymbol", item.visualSymbol)
            }
            array.put(obj)
        }

        prefs.edit().putString(KEY_CUSTOM_PRODUCTS, array.toString()).apply()
    }

    /**
     * Charge les produits personnalisés sauvegardés sur l'appareil.
     * Garantit l'absence de doublons avec les 6 produits de démonstration (IDs 1 à 6).
     */
    fun loadCustomProducts(): List<MainActivity.ProductItem> {
        val jsonStr = prefs.getString(KEY_CUSTOM_PRODUCTS, null) ?: return emptyList()
        val result = mutableListOf<MainActivity.ProductItem>()
        val seenIds = mutableSetOf(1, 2, 3, 4, 5, 6) // IDs protégés des 6 démos

        try {
            val array = JSONArray(jsonStr)
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                val id = obj.getInt("id")

                // Évite la création de doublon si l'ID est déjà présent
                if (id !in seenIds) {
                    seenIds.add(id)
                    result.add(
                        MainActivity.ProductItem(
                            id = id,
                            name = obj.getString("name"),
                            category = obj.getString("category"),
                            priceText = obj.getString("priceText"),
                            priceValue = obj.getLong("priceValue"),
                            description = obj.getString("description"),
                            visualSymbol = obj.optString("visualSymbol", "📦"),
                            isCustom = true
                        )
                    )
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        return result
    }

    // =========================================================================
    // GESTION DES COMMANDES LOCALES
    // =========================================================================

    /**
     * Génère un identifiant de commande unique et lisible (ex: CMD-20261028-1545-842).
     */
    fun generateOrderId(): String {
        val sdf = SimpleDateFormat("yyyyMMdd-HHmm", Locale.FRANCE)
        val datePart = sdf.format(Date())
        val randomPart = (100..999).random()
        return "CMD-$datePart-$randomPart"
    }

    /**
     * Formate une date lisible pour l'historique (ex: 28 oct. 2026 à 15:45).
     */
    fun formatCurrentDate(): String {
        val sdf = SimpleDateFormat("dd MMMM yyyy 'à' HH:mm", Locale.FRANCE)
        return sdf.format(Date())
    }

    /**
     * Enregistre une nouvelle commande confirmée sur l'appareil.
     * Prévention des doublons : vérifie si l'ID existe déjà avant insertion.
     */
    fun saveOrder(newOrder: OrderRecord): Boolean {
        val currentOrders = loadOrders().toMutableList()

        // Vérification stricte anti-doublon
        if (currentOrders.any { it.id == newOrder.id }) {
            return false
        }

        // Ajout de la nouvelle commande en tête de liste (la plus récente d'abord)
        currentOrders.add(0, newOrder)
        return persistOrdersList(currentOrders)
    }

    /**
     * Charge l'ensemble des commandes enregistrées localement sur l'appareil.
     * Déduplication automatique garantie.
     */
    fun loadOrders(): List<OrderRecord> {
        val jsonStr = prefs.getString(KEY_CONFIRMED_ORDERS, null) ?: return emptyList()
        val result = mutableListOf<OrderRecord>()
        val seenIds = mutableSetOf<String>()

        try {
            val array = JSONArray(jsonStr)
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                val id = obj.getString("id")

                // Évite tout doublon de commande
                if (id !in seenIds) {
                    seenIds.add(id)

                    val itemsArray = obj.getJSONArray("items")
                    val itemsList = mutableListOf<OrderItemRecord>()

                    for (j in 0 until itemsArray.length()) {
                        val itemObj = itemsArray.getJSONObject(j)
                        itemsList.add(
                            OrderItemRecord(
                                productId = itemObj.getInt("productId"),
                                productName = itemObj.getString("productName"),
                                unitPrice = itemObj.getLong("unitPrice"),
                                quantity = itemObj.getInt("quantity"),
                                subtotal = itemObj.getLong("subtotal")
                            )
                        )
                    }

                    result.add(
                        OrderRecord(
                            id = id,
                            timestamp = obj.getLong("timestamp"),
                            dateFormatted = obj.getString("dateFormatted"),
                            clientName = obj.getString("clientName"),
                            clientPhone = obj.getString("clientPhone"),
                            clientCity = obj.getString("clientCity"),
                            clientDistrict = obj.getString("clientDistrict"),
                            totalAmount = obj.getLong("totalAmount"),
                            items = itemsList
                        )
                    )
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        // Tri chronologique décroissant (plus récentes en premier)
        return result.sortedByDescending { it.timestamp }
    }

    /**
     * Supprime une commande de l'appareil (ex: après traitement par le commerçant).
     */
    fun deleteOrder(orderId: String): Boolean {
        val currentOrders = loadOrders().filter { it.id != orderId }
        return persistOrdersList(currentOrders)
    }

    /**
     * Supprime l'ensemble des commandes enregistrées localement.
     */
    fun clearAllOrders(): Boolean {
        return prefs.edit().remove(KEY_CONFIRMED_ORDERS).commit()
    }

    /**
     * Sérialise la liste de commandes en JSON dans SharedPreferences.
     */
    private fun persistOrdersList(orders: List<OrderRecord>): Boolean {
        val distinctOrders = orders.distinctBy { it.id }
        val array = JSONArray()

        for (ord in distinctOrders) {
            val obj = JSONObject().apply {
                put("id", ord.id)
                put("timestamp", ord.timestamp)
                put("dateFormatted", ord.dateFormatted)
                put("clientName", ord.clientName)
                put("clientPhone", ord.clientPhone)
                put("clientCity", ord.clientCity)
                put("clientDistrict", ord.clientDistrict)
                put("totalAmount", ord.totalAmount)

                val itemsArray = JSONArray()
                for (it in ord.items) {
                    val itObj = JSONObject().apply {
                        put("productId", it.productId)
                        put("productName", it.productName)
                        put("unitPrice", it.unitPrice)
                        put("quantity", it.quantity)
                        put("subtotal", it.subtotal)
                    }
                    itemsArray.put(itObj)
                }
                put("items", itemsArray)
            }
            array.put(obj)
        }

        return prefs.edit().putString(KEY_CONFIRMED_ORDERS, array.toString()).commit()
    }
}
